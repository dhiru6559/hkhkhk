package com.cg.lpg.util;

import java.sql.Connection;
import java.sql.SQLException;

import javax.sql.DataSource;
import javax.naming.InitialContext;
import javax.naming.NamingException;

import com.cg.lpg.exception.LPGException;
public class DBUtil {
	static Connection connection;
	public static Connection obtainConnection() throws LPGException{
		try {
			InitialContext context=new InitialContext();
			DataSource source=(DataSource) context.lookup("java:/OracleDS");
			connection=source.getConnection();
		} catch (NamingException e) {
			throw new LPGException("Error while creating datasource:"+e.getMessage());
			
		} catch (SQLException e) {
			throw new LPGException("Error while obtaining connection"+e.getMessage());
		}
		return connection;
	}
}
