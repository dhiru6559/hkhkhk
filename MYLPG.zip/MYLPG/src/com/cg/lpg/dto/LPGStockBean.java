package com.cg.lpg.dto;

import java.time.LocalDate;

public class LPGStockBean {
	private int avQty;
	private LocalDate receivedDate;
	private String updatedBy;
	private String location;
	public LPGStockBean() {
		super();
		
	}
	public int getAvQty() {
		return avQty;
	}
	public void setAvQty(int avQty) {
		this.avQty = avQty;
	}
	public LocalDate getReceivedDate() {
		return receivedDate;
	}
	public void setReceivedDate(LocalDate receivedDate) {
		this.receivedDate = receivedDate;
	}
	public String getUpdatedBy() {
		return updatedBy;
	}
	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	

}
