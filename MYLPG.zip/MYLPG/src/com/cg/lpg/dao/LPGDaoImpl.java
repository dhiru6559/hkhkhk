package com.cg.lpg.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import com.cg.lpg.dto.LPGStockBean;
import com.cg.lpg.exception.LPGException;
import com.cg.lpg.util.DBUtil;

public class LPGDaoImpl implements ILPGDao{
	static Connection connection=null;
	
	static{
		try {
			connection=DBUtil.obtainConnection();
		} catch (LPGException e) {
			
			e.printStackTrace();
		}
	}
	@Override
	public ArrayList<LPGStockBean> getStockDetails(String location)
			throws LPGException {
		PreparedStatement statement=null;
		ResultSet resultSet=null;
		String query="SELECT * from LPGStock where location=?";
		System.out.println("Location is"+location);
		ArrayList<LPGStockBean> stockList=new ArrayList<LPGStockBean>();
		LPGStockBean bean=null;
		try{
			statement=connection.prepareStatement(query);
			statement.setString(1, location);
			resultSet=statement.executeQuery();
			while(resultSet.next()){
				System.out.println("ResultSet coming");
				bean=new LPGStockBean();
				bean.setAvQty(resultSet.getInt(1));
				bean.setReceivedDate(resultSet.getDate(2).toLocalDate());
				bean.setUpdatedBy(resultSet.getString(3));
				bean.setLocation(resultSet.getString(4));
				stockList.add(bean);
			}
		}
		catch(Exception e){
			throw new LPGException("something went wromg while fetching");
			
		}
		return stockList;
	}

	@Override
	public boolean updateStockDetails(int quantity, String provider)
			throws LPGException {
	PreparedStatement statement=null;
	int result=0;
	String query="UPDATE LPGSTOCL set avqty=avqty-? where updatedby=?";
	boolean flag=false;
	try{
		statement=connection.prepareStatement(query);
		statement.setInt(1,quantity);
		statement.setString(2,provider);
		result=statement.executeUpdate();
		if(result>0)
			flag=true;
		else
			throw new LPGException("Something went wrong");
		
	}
	catch(Exception e){
		throw new LPGException("Unable to update  stock details");
	}
	return flag;
	}

}
