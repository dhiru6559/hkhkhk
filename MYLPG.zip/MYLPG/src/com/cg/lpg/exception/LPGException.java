package com.cg.lpg.exception;

public class LPGException extends Exception{
	public LPGException(String msg){
		super(msg);
	}

}
