package com.cg.myair.service;

import com.cg.myair.bean.UserBean;
import com.cg.myair.dao.CustomerDaoImpl;
import com.cg.myair.dao.ICustomerDao;
import com.cg.myair.exception.UserException;

public class CustomerServiceImpl implements ICustomerService {

	
	ICustomerDao dao =new CustomerDaoImpl();
	@Override
	public UserBean insertDetails(UserBean bean) throws UserException {
		return dao.insertDetails(bean);
		
	}
	@Override
	public boolean validatePassword(String password, String passwd) throws UserException {
		boolean flag=false;
		if(password.equals(passwd)) {
			flag=true;
		}
		return flag;
	}
	@Override
	public boolean checkAmount(String amnt) throws UserException {
		
		boolean flag=false;
		int amount=Integer.parseInt(amnt);
		if(amount>0 && amount<750)
			flag=true;
		return flag;
	}
	
}
