package com.cg.myair.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.cg.myair.bean.UserBean;
import com.cg.myair.exception.UserException;
import com.cg.myair.util.DBUtil;

public class CustomerDaoImpl implements ICustomerDao {
	
	Connection con;
	public CustomerDaoImpl() {
		
		try {
			con=DBUtil.obtainConnection();
		} catch (UserException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Override
	public UserBean insertDetails(UserBean bean) throws UserException {
		String sql="Insert into users values(?,?,?,?)";
		PreparedStatement pst=null;
		ResultSet result=null;
		boolean flag=false;
		int billId=0;
		try {
			pst=con.prepareStatement(sql);
			con.setAutoCommit(false);
			pst.setString(1,bean.getName());
			pst.setString(2,bean.getUserName());
			pst.setString(3,bean.getPassword());
			pst.setString(4,bean.getMobileNumber());
			result=pst.executeQuery();
			if(result!=null) {
				flag=true;
			}
			con.commit();
		} catch (SQLException e) {
			throw new UserException("Registration Failed");
		}
		return bean;
	}

}
