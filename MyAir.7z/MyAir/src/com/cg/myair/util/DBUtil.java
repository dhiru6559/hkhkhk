package com.cg.myair.util;	

import java.sql.Connection;
import java.sql.SQLException;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;


import com.cg.myair.exception.UserException;
public class DBUtil {
	static Connection connection;
	public static Connection obtainConnection() throws UserException{
		try {
			InitialContext context=new InitialContext();
			DataSource source=(DataSource) context.lookup("java:/OracleDS");
			connection=source.getConnection();
		} catch (NamingException e) {
			throw new UserException("Error while creating datasource:"+e.getMessage());
			
		} catch (SQLException e) {
			throw new UserException("Error while obtaining connection"+e.getMessage());
		}
		return connection;
	}
}
