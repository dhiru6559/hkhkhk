import static org.junit.Assert.*;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.junit.Test;

import com.cg.mobileApp.dao.IMobileImpl;
import com.cg.mobileApp.dao.MobileImpl;
import com.cg.mobileApp.dto.MobileBean;
import com.cg.mobileApp.exception.MobileException;
import com.cg.mobileApp.service.IMobileService;
import com.cg.mobileApp.service.MobileService;


public class Tester {

	@Test
	public void testInsertDetails() throws MobileException, SQLException {
		MobileBean fb=new MobileBean();
		fb.setCustomerName("Almas");
		fb.setMailID("almas@gmail.com");
		fb.setPhno("8765432109");
		fb.setMobID(1027);
		IMobileService im=new MobileService();
		int res=im.insertRows(fb);
		assertTrue(res>1000);
		
	}
	
	@Test
	public void testViewDetails() throws MobileException, SQLException {
		MobileBean fb=new MobileBean();
		IMobileService im=new MobileService();
		List<MobileBean> list=new ArrayList<MobileBean>();
		list=im.viewDetails(fb);
		assertTrue(list.size()>0);
		
	}
	
	@Test
	public void testupdateQuantity() throws MobileException, SQLException {
		IMobileService im=new MobileService();
		int res=im.updateQuantity(1027,"10");
		assertTrue(res > 0);
	}
	
	@Test
	public void testDeleteRows() throws MobileException, SQLException{
		IMobileImpl im=new MobileImpl();
		int res=im.deleteRow(1024);
		assertTrue(res > 0);
	}
	
	@Test
	public void testSearch() throws MobileException, SQLException{
		IMobileService im=new MobileService();
		List<MobileBean> list=new ArrayList<MobileBean>();
		list=im.search(0,100000);
		assertTrue(list.size() > 0 );
	}
}
