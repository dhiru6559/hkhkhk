package com.cg.mobileApp.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import com.cg.mobileApp.dto.MobileBean;
import com.cg.mobileApp.exception.MobileException;
import com.cg.mobileApp.util.DBConnection;

public class MobileImpl implements IMobileImpl{

	public int insertRows(MobileBean mobile) throws MobileException, SQLException{
		Connection con=DBConnection.getInstance().getConnection();	
		PreparedStatement ps=null;
		int queryResult=0,queryResult1=0,pid=0;
		
		try{
			
		ps=con.prepareStatement(QueryMapper.INSERT_QUERY);
		ps.setString(1,mobile.getCustomerName());
		ps.setString(2,mobile.getMailID());
		ps.setString(3,mobile.getPhno());
		ps.setInt(4,mobile.getMobID());
		
		ResultSet rs=ps.executeQuery();
		}
		catch(SQLException e)
		{
			DBConnection.mylogger.info("Insertion unsuccessful");
			throw new MobileException("Insertion not possible");
		}
		try{
		ps = con.prepareStatement(QueryMapper.UPDATE_IQUERY);
		ps.setInt(1,mobile.getMobID());
		queryResult1=ps.executeUpdate();
		
		}
		catch(SQLException e)
		{
			DBConnection.mylogger.info("Update after insert unsuccessful");
			throw new MobileException("Updation not possible");
		}
		ps=con.prepareStatement(QueryMapper.RETURN_PID);
		queryResult=ps.executeUpdate();
		ResultSet rs=ps.executeQuery();
		if(rs.next())
		{
			pid=rs.getInt(1);
		}
		
		return pid;

}

	@Override
	public int updateQuantity(int mobileid,String units) throws MobileException,
			SQLException {
		Connection con=DBConnection.getInstance().getConnection();	
		PreparedStatement ps=null;
		Scanner sc=new Scanner(System.in);
		int queryResult=0;
		try{
		ps=con.prepareStatement(QueryMapper.UPDATE_IQUERY1);
		ps.setInt(1,mobileid);
		ps.setString(2,units);
		ps.setInt(3, mobileid);
		queryResult=ps.executeUpdate();
		}
		catch(SQLException e)
		{
			throw new MobileException("Updation not possible");
		}
		
		return queryResult;

	}
	@Override
	public int deleteRow(int mobileid) throws MobileException,
			SQLException {
	
		Connection con=DBConnection.getInstance().getConnection();	
		PreparedStatement ps=null;
		
		int queryResult=0;
		try{
			
		ps=con.prepareStatement(QueryMapper.DELETE_QUERY);
		ps.setInt(1,mobileid);
		queryResult=ps.executeUpdate();
	
		}
		catch(SQLException e)
		{
			DBConnection.mylogger.info("Deletion unsuccessful");
			throw new MobileException("Deletion not possible"+e.getMessage());
		}
		return queryResult;

	}
	@Override
	public List<MobileBean> viewDetails(MobileBean mobile) throws MobileException,
			SQLException {
		List<MobileBean> list=new ArrayList<MobileBean>();
		Connection con=DBConnection.getInstance().getConnection();	
		PreparedStatement ps=null;
		ResultSet rs=null;
			int queryResult=0;
			try{
			ps=con.prepareStatement(QueryMapper.VIEW_DETAILS_QUERY);
			queryResult=ps.executeUpdate();
			rs=ps.executeQuery();
			
			}
			catch(SQLException e)
			{
				DBConnection.mylogger.info("Details could not be displayed");
				throw new MobileException("Details cannot be viewed");
			}
			
			while(rs.next())
				{
				
				 mobile.setMobID(rs.getInt(1));
				 mobile.setPname(rs.getString(2));
				 mobile.setPrice(rs.getFloat(3));
				 mobile.setQuantity(rs.getString(4));
				 list.add(mobile);
				 mobile=new MobileBean();
						
				}
			
			if(queryResult>0)
			{
				DBConnection.mylogger.info("Details successfully displayed ");
				System.out.println("Details successfully displayed");
			}
			return list;
		
	}

	
	@Override
	public List<MobileBean> search(float price1, float price2) throws MobileException,
			SQLException {
		MobileBean mobile=new MobileBean();
		List<MobileBean> list=new ArrayList<MobileBean>();
		Connection con=DBConnection.getInstance().getConnection();	
		PreparedStatement ps=null;
		ResultSet rs=null;
		try{
		ps=con.prepareStatement(QueryMapper.SEARCH);
		ps.setFloat(1,price1);
		ps.setFloat(2,price2);
		rs=ps.executeQuery();
		}
		catch(SQLException e)
		{
			DBConnection.mylogger.info("Requested data not found");
			throw new MobileException("No phones available in the desired price range");
		}
		try{
			
			while(rs.next())
			{
				mobile.setPname(rs.getString(2));
				list.add(mobile);
				mobile=new MobileBean();
			}
		}
		catch(SQLException e)
		{
			DBConnection.mylogger.error("Records not available");
			throw new MobileException("No records available");
		}
		return list;
		
	}
	
	
		}
		
	
	
