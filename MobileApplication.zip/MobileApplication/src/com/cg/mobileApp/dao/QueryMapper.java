package com.cg.mobileApp.dao;

public interface QueryMapper {

	public static final String SEARCH="SELECT mobileid,name,price,quantity FROM mobiles WHERE price BETWEEN ? AND ?";
	public static final String VIEW_DETAILS_QUERY="SELECT mobileid,name,price,quantity FROM mobiles";
	public static final String INSERT_QUERY="INSERT INTO purchasedetails VALUES(pID_seq.NEXTVAL,?,?,?,SYSDATE,?)";
	public static final String DELETE_QUERY="DELETE FROM mobiles WHERE mobileid=?";
	public static final String UPDATE_IQUERY="UPDATE mobiles SET quantity = (SELECT quantity FROM mobiles WHERE mobileid=?)-1";
	public static final String UPDATE_IQUERY1="UPDATE mobiles SET quantity = (SELECT quantity FROM mobiles WHERE mobileid=?)+? WHERE mobileid = ?";
	public static final String RETURN_PID="SELECT pID_seq.CURRVAL FROM purchasedetails ";
}
