package com.cg.mobileApp.dao;

import java.sql.SQLException;
import java.util.List;

import com.cg.mobileApp.dto.MobileBean;
import com.cg.mobileApp.exception.MobileException;

public interface IMobileImpl {
	public int insertRows(MobileBean mobile) throws MobileException, SQLException;
	public List<MobileBean> viewDetails(MobileBean mobile) throws MobileException, SQLException;
	public int updateQuantity(int mobileid,String units)throws MobileException, SQLException;
	public int deleteRow(int mobileid)throws MobileException, SQLException;
	public List<MobileBean> search(float price1,float price2)throws MobileException, SQLException;
}
