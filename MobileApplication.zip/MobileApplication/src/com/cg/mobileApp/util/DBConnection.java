package com.cg.mobileApp.util;
import java.io.FileInputStream;

import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.cg.mobileApp.exception.MobileException;

public class DBConnection {
	private static Connection connection;
	private static DBConnection instance;
	public static Logger mylogger=Logger.getLogger(DBConnection.class.getName());
	private DBConnection(){
		PropertyConfigurator.configure("resource/log4j.properties");
	}
	
	public static DBConnection getInstance(){
		if(instance==null)
			instance=new DBConnection();
		return instance;
	}
	
	public Connection getConnection() throws MobileException
	{
		
	   if(connection==null){
		try
		{
			//DriverManager.registerDriver (new oracle.jdbc.driver.OracleDriver());
			String fileName="resource/dbConnection.properties";
			Properties prop=new Properties();
			InputStream inputStream =new FileInputStream(fileName);
			
		         
		      prop.load(inputStream);
		      inputStream.close();
		      String connectionURL = prop.getProperty("jdbc.url");
		      String username = prop.getProperty("jdbc.user");
		      String password = prop.getProperty("jdbc.password");
		    
		      connection=DriverManager.getConnection(connectionURL,username,password);
		     
			
		}
		
		
		catch(SQLException e)
		{
			DBConnection.mylogger.error("Database connecrion failed");
			throw new MobileException("Please check oracle credentials "+e);
		}
		
		catch(Exception e)
		{
			throw new MobileException("message from DB/Class:"+e.getMessage());
		}

	   }
return connection;

	}
}

