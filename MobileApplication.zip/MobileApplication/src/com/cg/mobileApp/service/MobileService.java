package com.cg.mobileApp.service;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.cg.mobileApp.dao.IMobileImpl;
import com.cg.mobileApp.dao.MobileImpl;
import com.cg.mobileApp.dto.MobileBean;
import com.cg.mobileApp.exception.MobileException;

public class MobileService implements IMobileService {

	@Override
	public boolean isValid(MobileBean mobile) throws MobileException {
		Pattern pattern=Pattern.compile("^[A-Z][A-Za-z]{4,19}$");
		Matcher m=pattern.matcher(mobile.getCustomerName());
		if(!m.find()){
			throw new MobileException ("Invalid customer name");
			}
		Pattern p1=Pattern.compile("^[a-z]*@[a-z]*.com$");
		Matcher m1=p1.matcher(mobile.getMailID());
		if(!m1.find()){
			throw new MobileException ("Invalid email id");
			}
		Pattern p2=Pattern.compile("[0-9]{10}");
		Matcher m2=p2.matcher(mobile.getPhno());
		if(!m2.find()){
			throw new MobileException ("Invalid phone number");
			}
		Pattern p3=Pattern.compile("[0-9]{4}");
		Matcher m3=p3.matcher(Integer.toString(mobile.getMobID()));
		if(!m3.find()){
			throw new MobileException ("Invalid mobile id");
			}
			
	
		return true;
	}

	@Override
	public int insertRows(MobileBean mobile) throws MobileException,
			SQLException {
		IMobileImpl im=new MobileImpl();
		int res=im.insertRows(mobile);
		return res;
	}

	@Override
	public List<MobileBean> viewDetails(MobileBean mobile)
			throws MobileException, SQLException {
		IMobileImpl im=new MobileImpl();
		List<MobileBean> list=new ArrayList<MobileBean>();
		list=im.viewDetails(mobile);
		
		return list;
	}

	@Override
	public int updateQuantity(int mobileid, String units)
			throws MobileException, SQLException {
		IMobileImpl im=new MobileImpl();
		int res=im.updateQuantity(mobileid,units);
		return res;
	}

	@Override
	public int deleteRows(int mobileid) throws MobileException, SQLException {
		System.out.println("Inside deleteRows of MobileService");
		IMobileImpl im=new MobileImpl();
		int res=im.deleteRow(mobileid);
		System.out.println("Exiting deleteRows of MobileService");
		return res;
	}

	@Override
	public List<MobileBean> search(float price1, float price2)
			throws MobileException, SQLException {
		IMobileImpl im=new MobileImpl();
		List<MobileBean> list=new ArrayList<MobileBean>();
		list=im.search(price1,price2);
		return list;
	}

}
