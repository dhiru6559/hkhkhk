package com.cg.mobileApp.service;

import java.sql.SQLException;
import java.util.List;

import com.cg.mobileApp.dto.MobileBean;
import com.cg.mobileApp.exception.MobileException;

public interface IMobileService {

	boolean isValid(MobileBean mobile) throws MobileException;
	public int insertRows(MobileBean mobile) throws MobileException, SQLException;
	public List<MobileBean> viewDetails(MobileBean mobile) throws MobileException, SQLException;
	public int updateQuantity(int mobileid,String units)throws MobileException, SQLException;
	public int deleteRows(int mobileid)throws MobileException, SQLException;
	public List<MobileBean> search(float price1,float price2)throws MobileException, SQLException;
}
