package com.cg.mobileApp.pl;

import java.sql.SQLException;

import java.util.ArrayList;
//import java.util.Date;
import java.util.List;
import java.util.Scanner;
//import java.util.logging.Logger;

import com.cg.mobileApp.exception.MobileException;
import com.cg.mobileApp.service.IMobileService;
import com.cg.mobileApp.service.MobileService;
//import com.cg.mobileApp.dao.MobileImpl;
import com.cg.mobileApp.dto.MobileBean;



public class MobileMain {

	private static Scanner sc;
	
	
	public static void main(String[] args) throws MobileException, SQLException {
		String customerName,mailID,phno,units;//,quantity
		int mobID,choice,res;//purchaseID;
		float price1,price2;
	//	Date purchaseDate;
	//	String ch;
		sc = new Scanner(System.in);
	//	MobileImpl mob=new MobileImpl();
		MobileBean mob1=new MobileBean();
		IMobileService imob=new MobileService();
		do{
			System.out.println("Choose the desired option:\n1.Insertion of rows\n2.Updation of Mobile quantity\n3.View details of mobiles\n4.Delete mobile details\n5.Search mobiles\n6.Exit");
			choice=sc.nextInt();
			switch(choice){
			case 1:
					System.out.println("Enter details:\nEnter customer name:\n");
					customerName=sc.next();
					mob1.setCustomerName(customerName);
					System.out.println("Enter your mailID:\n");
					mailID=sc.next();
					mob1.setMailID(mailID);
					System.out.println("Enter phone number:\n");
					phno=sc.next();
					mob1.setPhno(phno);
					System.out.println("Enter mobileID:\n");
					mobID=sc.nextInt();
					mob1.setMobID(mobID);
					
					if(imob.isValid(mob1))
					{
						int pid=imob.insertRows(mob1);
						
						System.out.println("PurchaseID:"+pid);
						
							
					} 
				
					break;
			case 2:System.out.println("Enter mobile ID:");
					mobID=sc.nextInt();
					System.out.println("Enter the number of mobile units to update:");
					units=sc.next();
					int res1=imob.updateQuantity(mobID,units);
					if(res1>0){
						System.out.println("Updation successfully implemented");
					}
					break;
			case 3:List<MobileBean> list=new ArrayList<MobileBean>();
					list=imob.viewDetails(mob1);
					System.out.println("MobileID      Name		  Price     	Quantity");
					System.out.println("________________________________________________________________________");
					for(MobileBean mb:list)
					{
						System.out.println(mb.getMobID()+"      	"+mb.getPname()+"      	"+mb.getPrice()+"      	"+mb.getQuantity());
					}
					break;
			case 4:	System.out.println("Enter mobile ID:");
					mobID=sc.nextInt();
					int res2=imob.deleteRows(mobID);
					if(res2>0){
						System.out.println("Deletion successfully implemented");
					}
					break;	
			case 5:List<MobileBean> list1=new ArrayList<MobileBean>();
					System.out.println("Enter starting price:");
			       price1=sc.nextFloat();
			       System.out.println("Enter ending price:");
			       price2=sc.nextFloat();
			       list1=imob.search(price1,price2);
			       System.out.println("List of mobile devices available in the entered price range:\n");
			       for(MobileBean mb:list1)
					{
						System.out.println(mb.getPname()+"\n");
					}
			       break;
			case 6:System.exit(0);
			}System.out.println("Do you want to continue:\n1:Yes\n2:No\n");
			res=sc.nextInt();
			if(res==2)
				System.exit(1);
		} while(true);
	}
}

		
				

	