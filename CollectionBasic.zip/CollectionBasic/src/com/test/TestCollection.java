package com.test;
import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.LinkedList;
import java.util.TreeSet;
import java.util.Vector;

public class TestCollection {
	
	public static void main(String[] args) {
		
		//Collection list=new HashSet();//no duplicates //unordered
		//Collection list=new LinkedHashSet();//ordered
		//Collection list=new TreeSet(); //sorted alphabetically in the given input
		List list=new ArrayList();
		//Collection list=new Vector(); //synchronized
		//Collection list=new ArrayList();//fast searching
		//Collection list=new LinkedList();//more insertion and deletion
		//ArrayList list=new ArrayList();
		//Collection list=new ArrayList();
		
		list.add("6");
		list.add("2");
		list.add("9");
		list.add("banana");
		//Collections.sort(list);
		//Collections.reverse(list);
		//Collections.shuffle(list);
		Collections.max(list);
	//	System.out.println(list.add("banana"));
		//list.add(0,"Grapes");
		
		for(Object obj:list){
			String str=(String)obj;
			System.out.println(str.length());
		}
		System.out.println("*****************");
		
		
		Iterator iterator=list.iterator();
		
		
		while(iterator.hasNext()){
		Object obj=iterator.next();
		System.out.println(obj);
		}
		System.out.println("*****************");
		
		list.forEach(p->System.out.println(p)); //jdk1.8 lambda expression
		
	/*	for(int i=0;i<list.size();i++){
			System.out.println(list.get(i));
		}
		int n=list.size();
		list.clear();
		System.out.println("Size= "+n);
		String obj=(String)list.get(1);
		System.out.println(obj);
	*/
		}
	
}
