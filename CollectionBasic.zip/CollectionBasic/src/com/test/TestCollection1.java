package com.test;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

public class TestCollection1 {
	
	public static void main(String[] args) {
		List list=new ArrayList();
		//Set list=new TreeSet(new EmployeeComparator());
		
		Iterator iterator=list.iterator();
		
		Employee e1=new Employee(2001,"John",9000);
		Employee e2=new Employee(1001,"Jamu",8000);
		Employee e3=new Employee(200,"Amar",6000);
		
		list.add(e1);
		list.add(e2);
		list.add(e3);
		Collections.sort(list);
		//Collections.sort(list,new EmployeeComparator());
	/*	for(Object ob: list){
			Employee emp=(Employee) ob;
			System.out.println(emp);
		}
		while(iterator.hasNext()){
			Object obj=iterator.next();
			System.out.println(obj);
			}
			System.out.println("*****************");*/
		//list.forEach(p->System.out.println(p));
		list.forEach(p->System.out.println(p));
	}
}
