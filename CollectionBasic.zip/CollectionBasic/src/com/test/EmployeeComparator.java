package com.test;

import java.util.Comparator;

public class EmployeeComparator implements Comparator {

	@Override
	public int compare(Object o1, Object o2) {
		Employee e1=(Employee)o1;
		Employee e2=(Employee)o2;
		int n=e1.getEmployeeName().compareTo(e2.getEmployeeName());
		return 0;
	}

/*	@Override
	public int compare(Object obj1, Object obj2) {
		Employee e1=(Employee) obj1;
		Employee e2=(Employee) obj2;
		int n=e1.getEmployeeId()-e2.getEmployeeId();
		return 0;
	}
*/
}
