package com.test;

import java.util.Vector;

class MethodOverriding {
	 void add(int operand1, int operand2) {
		System.out.println(operand1 + operand2);
	}
}

public class Overridden extends MethodOverriding {
	public void show() {
		add(10, 12);
	}

	public static void main(String args[]) {
		Overridden ob = new Overridden();
		ob.show();

		Vector v1 = new Vector(7, 3);

		for (int num = 1; num <= 15; num++)
			v1.add(num);
		System.out.println(v1.capacity());

	}
}
