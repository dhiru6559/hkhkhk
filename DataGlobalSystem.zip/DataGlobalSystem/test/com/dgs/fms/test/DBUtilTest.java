package com.dgs.fms.test;

import java.sql.Connection;



import javax.sql.DataSource;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.dgs.fms.dao.FMSDaoImpl;
import com.dgs.fms.exception.FMSException;
import com.dgs.fms.util.DBUtil;

public class DBUtilTest {
	static FMSDaoImpl daotest;
	static Connection dbCon;
	
	/*
	@BeforeClass
	public static void initialise() {
		daotest = new FMSDaoImpl();
		dbCon = null;
	}

	@Before
	public void beforeEachTest() {
		System.out.println("----Starting DBConnection Test Case----\n");
	}

	*/
	
	
	@Test
	public void test() throws FMSException 
	{
		dbCon = DBUtil.getConnection();		
		Assert.assertNotNull(dbCon);
	}

	
	/*
	@After
	public void afterEachTest() {
		System.out.println("----End of DBConnection Test Case----\n");
	}

	@AfterClass
	public static void destroy() {
		System.out.println("\t----End of Tests----");
		daotest = null;
		dbCon = null;
	}
	
	*/

}
