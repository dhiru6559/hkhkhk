package com.dgs.fms.test;

import static org.junit.Assert.assertNotNull;
import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;

import com.dgs.fms.dao.FMSDaoImpl;
import com.dgs.fms.dto.CourseMaster;
import com.dgs.fms.dto.DemoView;
import com.dgs.fms.dto.EmployeeMaster;
import com.dgs.fms.dto.FacultySkillView;
import com.dgs.fms.dto.FeedbackMaster;
import com.dgs.fms.exception.FMSException;

public class FMSDaoImplTest {
	
	static FMSDaoImpl dao;
	static CourseMaster course ;
	static EmployeeMaster employee;
	static FeedbackMaster feedback;
	static FacultySkillView skillView;
	static DemoView demoView;

	@BeforeClass
	public static void initialize() {
		System.out.println("in before class");
		dao = new FMSDaoImpl();
		course = new CourseMaster();
		employee = new EmployeeMaster();
		feedback = new FeedbackMaster();
		skillView =  new FacultySkillView();
		demoView = new DemoView();
		
	}

	/************************************
	 * Test case for insert feedback()
	 * 
	 ************************************/
	
	@Test
	public void testinsertFeedback() throws FMSException 
	{
		assertNotNull(dao.insertFeedback(feedback));

	}

	
	@Test
	public void testmatchLogin() throws FMSException 
	{
		String empName = "Surabhi";
		/*
		employee.setEmployeeName("Priyanka"); 
		employee.setPassword("priya123");
		employee.setRole("participant");
		*/
		
		employee = dao.matchLogin(empName);
		//String password = employee.getPassword();
		
	
		Assert.assertEquals("login successful", employee.getPassword(), "admin123");
		
	}
}

	/************************************
	 * Test case for addDonarDetails()
	 * 
	 ************************************/
/*
	@Test
	public void testAddDonarDetails2() throws FMSException {

		donor.setDonorName("Shashwathi");
		donor.setPhoneNumber("9876543210");
		donor.setAddress("whitefield");
		donor.setDonationAmount(5000);
		assertTrue("Data Inserted successfully",
				Integer.parseInt(dao.addDonorDetails(donor)) > 1000);

	}


	@Test
	public void testViewAll() throws DonorException {
		assertNotNull(dao.retriveAllDetails());
	}


	@Test
	public void testById() throws DonorException {
		assertNotNull(dao.viewDonorDetails("1010"));
	}

	@Ignore
	@Test
	public void testById1() throws DonorException {
		assertEquals("TestName", dao.viewDonorDetails("1010").getDonorName());
	}
}

*/
