package com.dgs.fms.dto;

public class EmployeeMaster {

	private int employeeId;
	private String emlpoyeeName;
	private String password;
	private String role;
	
	public int getEmployeeId() {
		return employeeId;
	}
	public void setEmployeeId(int employeeId) {
		this.employeeId = employeeId;
	}
	public String getEmlpoyeeName() {
		return emlpoyeeName;
	}
	public void setEmlpoyeeName(String emlpoyeeName) {
		this.emlpoyeeName = emlpoyeeName;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	
}
