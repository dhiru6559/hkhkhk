package com.dgs.fms.service;

import com.dgs.fms.dao.FMSDaoImpl;
import com.dgs.fms.dao.IFMSDao;
import com.dgs.fms.dto.FeedbackMaster;
import com.dgs.fms.exception.FMSException;

public class FMSServiceImpl implements IFMSService {

	
	IFMSDao daoService=new FMSDaoImpl();
	@Override
	public int insertFeedback(FeedbackMaster feedback) throws FMSException {
		return daoService.insertFeedback(feedback);
	}

}
