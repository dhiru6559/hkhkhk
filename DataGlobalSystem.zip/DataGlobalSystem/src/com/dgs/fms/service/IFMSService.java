package com.dgs.fms.service;

import com.dgs.fms.dto.FeedbackMaster;
import com.dgs.fms.exception.FMSException;

public interface IFMSService {
	public int insertFeedback(FeedbackMaster feedback) throws FMSException;

}
