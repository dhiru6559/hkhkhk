package com.dgs.fms.service;

import java.util.List;

import com.dgs.fms.dto.DemoView;
import com.dgs.fms.dto.EmployeeMaster;
import com.dgs.fms.dto.FeedbackMaster;
import com.dgs.fms.exception.FMSException;

public interface IFMSService {
	public int insertFeedback(FeedbackMaster feedback) throws FMSException;
	public EmployeeMaster matchLogin(String employeeName) throws FMSException; 
	public List<DemoView> showMonthlyFeedback(String month) throws FMSException;


}
