package com.dgs.fms.util;

import java.sql.Connection;
import java.sql.SQLException;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import com.dgs.fms.exception.FMSException;

public class DBUtil {

	public static Connection getConnection() throws FMSException {
		InitialContext context = null;
		DataSource ds = null;
		try {
			context = new InitialContext();
			ds = (DataSource) context.lookup("java:/oracleDs");
			return ds.getConnection();

		} catch (NamingException e) {
			throw new FMSException(e.getMessage());
		} catch (SQLException e) {
			throw new FMSException(e.getMessage());
		}
	}
}
