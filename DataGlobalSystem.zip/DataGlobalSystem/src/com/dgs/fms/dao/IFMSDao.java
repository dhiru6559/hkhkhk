package com.dgs.fms.dao;

import com.dgs.fms.dto.FeedbackMaster;
import com.dgs.fms.exception.FMSException;

public interface IFMSDao {
	public int insertFeedback(FeedbackMaster feedback) throws FMSException;

}
