package com.dgs.fms.dao;

import java.util.List;

import com.dgs.fms.dto.CourseMaster;
import com.dgs.fms.dto.DemoView;
import com.dgs.fms.dto.EmployeeMaster;
import com.dgs.fms.dto.FacultySkill;
import com.dgs.fms.dto.FacultySkillView;
import com.dgs.fms.dto.FeedbackMaster;
import com.dgs.fms.exception.FMSException;

public interface IFMSDao {
	public int insertFeedback(FeedbackMaster feedback) throws FMSException;
	public List<DemoView> showMonthlyFeedback(String month) throws FMSException;
	public EmployeeMaster matchLogin(String employeeName) throws FMSException; 
	public List<FacultySkillView> mapFacultySkills() throws FMSException;
	public boolean deleteFacultyRecord(int id) throws FMSException;
	public int updateFacultySkill(String courselist,int facultyid) throws FMSException;
	public List<CourseMaster> mapCourseSkills() throws FMSException;
	public int insertCourseRecord(String courseName,int noOfDays) throws FMSException;
	public int updateCourseList(String coursesname,int courseid,int noofdays) throws FMSException;
}
