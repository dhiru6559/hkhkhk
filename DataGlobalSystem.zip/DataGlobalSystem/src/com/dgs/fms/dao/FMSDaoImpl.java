package com.dgs.fms.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.dgs.fms.dto.CourseMaster;
import com.dgs.fms.dto.DemoView;
import com.dgs.fms.dto.EmployeeMaster;
import com.dgs.fms.dto.FacultySkillView;
import com.dgs.fms.dto.FeedbackMaster;
import com.dgs.fms.exception.FMSException;
import com.dgs.fms.util.DBUtil;

public class FMSDaoImpl implements IFMSDao {
	
	Logger logger = Logger.getLogger(FMSDaoImpl.class);
	
	public FMSDaoImpl(){
		PropertyConfigurator.configure("resources//log4j.properties");
	}

	Connection connection;
	PreparedStatement pstmt;
	Statement statement;
	ResultSet rst;
	EmployeeMaster emp;
	CourseMaster courseM;

	@Override
	public int insertFeedback(FeedbackMaster feedback) throws FMSException {
		logger.debug("Insert feedback method initiated");
		connection = DBUtil.getConnection();
		int id = 0;
		try {
			pstmt = connection
					.prepareStatement("INSERT INTO FEEDBACKMASTER VALUES(?,?,?,?,?,?,?,?,?,sysdate)");
			pstmt.setInt(1, feedback.getTrainingCode());
			pstmt.setInt(2, feedback.getParticipantId());
			pstmt.setInt(3, feedback.getFbPrsComm());
			pstmt.setInt(4, feedback.getFbClrfyDbts());
			pstmt.setInt(5, feedback.getFbTm());
			pstmt.setInt(6, feedback.getFbHndOut());
			pstmt.setInt(7, feedback.getFbHwSwNtwrk());
			pstmt.setString(8, feedback.getComments());
			pstmt.setString(9, feedback.getSuggestions());

			id = pstmt.executeUpdate();
			System.out.println("Feedback Entered");
			logger.info("Feedback successfully entered by participant");
		} catch (SQLException e) 
		{
			logger.error("Feedback failed to insert");
			throw new FMSException(e.getMessage());
			
		}

		return id;

	}

	@Override
	public EmployeeMaster matchLogin(String employeeName) throws FMSException {
		logger.info("Method to match login credentials initiated");
		System.out.println(employeeName);
		connection = DBUtil.getConnection();
		try {
			emp = new EmployeeMaster();
			String qry = "select employeeId,employeeName,password,role from employeeMaster where employeeName='"
					+ employeeName + "'";

			// pstmt.setString(1, employeeName);
			pstmt = connection.prepareStatement(qry);

			rst = pstmt.executeQuery();
			if (rst.next()) {
				emp.setEmployeeId(rst.getInt("employeeId"));
				emp.setEmployeeName(rst.getString("employeeName"));
				emp.setPassword(rst.getString("password"));
				emp.setRole(rst.getString("role"));
			
			}
			logger.info("Login successful");
		} catch (SQLException e) {
			logger.error("Login failed");
			e.printStackTrace();
		}

		return emp;
	}

	boolean a;

	@Override
	public List<DemoView> showMonthlyFeedback(String month) throws FMSException {
		logger.debug("Method to show monthly feedback initiated");
		
		List<DemoView> showFeedbackList = new ArrayList<DemoView>();
		try {
			connection = DBUtil.getConnection();
			statement = connection.createStatement();
			// String
			// qry="select tp.startdate,cm.coursename,em.employeename,fm.fbPrsComm,fm.fbClrfyDbts,fm.fbTm,fm.fbHndOut,fm.fbHwSwNtwrk from Trainingprogram tp join coursemaster cm on tp.coursecode=cm.courseid join employeemaster em on em.employeeid=tp.facultycode join feedbackmaster fm on fm.participantId=em.employeeid";
			// rst = statement.executeQuery(qry);
			String qry = "select * from demo_view where to_char( startdate,'mon') like'"
					+ month + "'";
			rst = statement.executeQuery(qry);
			// to_char( tp.startdate, 'mm' )
			while (rst.next()) {
				DemoView dv = new DemoView();

				dv.setStartDate(rst.getDate("startdate"));
				dv.setCourseName(rst.getString("coursename"));
				dv.setEmployeeName(rst.getString("employeename"));
				dv.setFbPrsComm(rst.getInt("fbPrsComm"));
				dv.setFbClrfyDbts(rst.getInt("fbClrfyDbts"));
				dv.setFbTm(rst.getInt("fbTm"));
				dv.setFbHndOut(rst.getInt("fbHndOut"));
				dv.setFbHwSwNw(rst.getInt("fbHwSwNtwrk"));

				showFeedbackList.add(dv);
			}
			logger.info("Monthly feedback displayed successfully");
		} catch (SQLException e) {
			// e.printStackTrace();
			logger.error("Could not fetch monthly feedback data. ");
			throw new FMSException(
					"Something went wrong while fetching showMonthly feedback");
		}

		return showFeedbackList;
	}

	@Override
	public List<FacultySkillView> mapFacultySkills() throws FMSException {
		logger.debug("Method to display faculty skills initiated");
		List<FacultySkillView> mapFacultyList = new ArrayList<FacultySkillView>();
		try {
			FacultySkillView facultySkill;
			connection = DBUtil.getConnection();
			statement = connection.createStatement();

			String qry = "select facultyId,employeeName as facultyName,skillset as courselist from employeemaster e join facultyskill f on e.employeeid=f.facultyid";
			rst = statement.executeQuery(qry);

			while (rst.next()) {
				facultySkill = new FacultySkillView();
				facultySkill.setFacultyId(rst.getInt("facultyId"));
				facultySkill.setEmployeeName(rst.getString("facultyName"));
				facultySkill.setSkillSet(rst.getString("courselist"));

				mapFacultyList.add(facultySkill);
				System.out.println(mapFacultyList);
			}
			logger.info("Faculty skillset displayed successfully");
		} catch (SQLException e) 
		{
			logger.error("Faculty skillset cannot be displayed");
			throw new FMSException(
					"Something went wrong while fetching showMonthly feedback");
		}

		return mapFacultyList;
	}

	@Override
	public boolean deleteFacultyRecord(int id) throws FMSException {
		logger.debug("method is called to delete faculty records");
		connection = DBUtil.getConnection();
		boolean flag = false;
		try {
			String qry = "delete from facultySkill where facultyId=" + id;
			pstmt = connection.prepareStatement(qry);

			pstmt.executeUpdate();
			flag = true;
			System.out.println("Bhai tu toh gyaaa");
			connection.setAutoCommit(true);
			logger.info("Faculty records deleted successfully");
		} 
		catch (SQLException e)
		{
			logger.error("Faculty records could not be deleted");
			throw new FMSException(e.getMessage());
		}

		return flag;
	}

	@Override
	public int updateFacultySkill(String courselist, int facultyid)
			throws FMSException {
		logger.info("Methods to update skills of faculty initiated");
		
		connection = DBUtil.getConnection();
		int id;
		try {
			String qry = "update facultyskill set skillset='" + courselist
					+ "' where facultyid=" + facultyid;
			pstmt = connection.prepareStatement(qry);
			id = pstmt.executeUpdate();
			System.out.println(facultyid);
			logger.info("Faculty skills updated successfully");
		} catch (SQLException e) {
			e.printStackTrace();
			logger.error("Updation of faculty skills failed");
		}

		return facultyid;
	}

	@Override
	public List<CourseMaster> mapCourseSkills() throws FMSException {
		logger.info("Method to display course skills initiated");
		
		List<CourseMaster> mapCoursesList = new ArrayList<CourseMaster>();
		try {
			CourseMaster mapCourses;
			connection = DBUtil.getConnection();
			statement = connection.createStatement();

			String qry = "select courseId,courseName,noOfDays from coursemaster";
			rst = statement.executeQuery(qry);

			while (rst.next()) {
				mapCourses = new CourseMaster();
				mapCourses.setCourseId(rst.getInt("courseId"));
				mapCourses.setCourseName(rst.getString("coursename"));
				mapCourses.setNoOfDays(rst.getInt("noofdays"));

				mapCoursesList.add(mapCourses);
				System.out.println(mapCoursesList);
			}
			logger.info("Course skills displayed successfully");
		} catch (SQLException e) 
		{
			logger.error("Course details could not be displayed");
			throw new FMSException("Something went wrong in course master");
		}

		return mapCoursesList;

	}

	@Override
	public int insertCourseRecord(String courseName,int noOfDays) throws FMSException {
		logger.info("Method to insert new course details initiated");
		
		connection = DBUtil.getConnection();
		int id = 0;
		try {
			courseM = new CourseMaster();
			System.out.println(courseM.getCourseName()+" "+courseM.getNoOfDays());
			pstmt = connection.prepareStatement("INSERT INTO courseMaster values(sq_courseId.nextval,'"+courseName+"',"+noOfDays+")");
//			pstmt.setString(1, courseM.getCourseName());
//			pstmt.setInt(2, courseM.getNoOfDays());
			id = pstmt.executeUpdate();
			connection.setAutoCommit(true);
			System.out.println("Course Details Entered");
			logger.info("New course details are inserted successfully");
		} 
		catch (SQLException e) 
		{
			logger.error("New course details could not be inserted ");
			throw new FMSException(e.getMessage());
		}

		return id;

	}

	@Override
	public int updateCourseList(int courseid, int noofdays) throws FMSException {
		logger.info("Methods to update existing course details initiated");
		

		connection = DBUtil.getConnection();
		int id;
		try {
			String qry = "update coursemaster set noofdays=" + noofdays
					+ " where courseid=" + courseid;
			pstmt = connection.prepareStatement(qry);
			id = pstmt.executeUpdate();
			System.out.println(courseid);
			logger.info("Coourse details are updated successfully");
		} catch (SQLException e) 
		{
			logger.error("Coourse details could not be updated ");
			e.printStackTrace();
		}

		return courseid;
	}

}
