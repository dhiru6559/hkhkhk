package com.dgs.fms.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;

import com.dgs.fms.dto.EmployeeMaster;
import com.dgs.fms.dto.FeedbackMaster;
import com.dgs.fms.exception.FMSException;
import com.dgs.fms.util.DBUtil;

public class FMSDaoImpl implements IFMSDao {

	Connection connection;
	PreparedStatement pstmt;
	Statement statement;
	ResultSet rst;
	EmployeeMaster emp;

	@Override
	public int insertFeedback(FeedbackMaster feedback) throws FMSException {
		connection = DBUtil.getConnection();
		int id = 0;
		try {
			pstmt = connection
					.prepareStatement("INSERT INTO FEEDBACKMASTER VALUES(?,?,?,?,?,?,?,?,?,sysdate)");
			pstmt.setInt(1, feedback.getTrainingCode());
			pstmt.setInt(2, feedback.getParticipantId());
			pstmt.setInt(3, feedback.getFbPrsComm());
			pstmt.setInt(4, feedback.getFbClrfyDbts());
			pstmt.setInt(5, feedback.getFbTm());
			pstmt.setInt(6, feedback.getFbHndOut());
			pstmt.setInt(7, feedback.getFbHwSwNtwrk());
			pstmt.setString(8, feedback.getComments());
			pstmt.setString(9, feedback.getSuggestions());

			id = pstmt.executeUpdate();
			System.out.println("Feedback Entered");
		} catch (SQLException e) {
			throw new FMSException(e.getMessage());
		}

		return id;

	}

	@Override
	public EmployeeMaster matchLogin(String employeeName) throws FMSException {
		
		System.out.println(employeeName);
		connection = DBUtil.getConnection();
		try {
			emp = new EmployeeMaster();
			String qry = "select employeeId,employeeName,password,role from employeeMaster where employeeName="+employeeName;
			
			//pstmt.setString(1, employeeName);
			pstmt=connection.prepareStatement(qry);
			
			rst = pstmt.executeQuery();
			if(rst.next())
			{
				emp.setEmployeeId(rst.getInt("employeeId"));
				emp.setEmployeeName(rst.getString("employeeName"));
				emp.setPassword(rst.getString("password"));
				emp.setRole(rst.getString("role"));
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return emp;
	}

}
