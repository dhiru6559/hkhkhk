package com.dgs.fms.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.dgs.fms.dto.FeedbackMaster;
import com.dgs.fms.exception.FMSException;
import com.dgs.fms.util.DBUtil;

public class FMSDaoImpl  implements IFMSDao{

	
	
	
	
	@Override
	public int insertFeedback(FeedbackMaster feedback) throws FMSException {
		Connection con=DBUtil.getConnection();
		int id=0;
		try {
			PreparedStatement stat=con.prepareStatement("INSERT INTO FEEDBACKMASTER VALUES(?,?,?,?,?,?,?,?,?)");
			stat.setInt(1, feedback.getTrainingCode());
			stat.setInt(2, feedback.getParticipantId());
			stat.setInt(3, feedback.getFbPrsComm());
			stat.setInt(4, feedback.getFbClrfyDbts());
			stat.setInt(5, feedback.getFbTm());
			stat.setInt(6, feedback.getFbHndOut());
			stat.setInt(7, feedback.getFbHwSwNtwrk());
			stat.setString(8, feedback.getComments());
			stat.setString(9, feedback.getSuggestions());
			id=stat.executeUpdate();
			System.out.println("entered feedback");
		} 
		catch (SQLException e) {
			throw new FMSException(e.getMessage());
		}
		
	return id;
		
	}

}
