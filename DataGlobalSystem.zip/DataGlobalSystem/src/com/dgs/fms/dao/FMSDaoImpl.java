package com.dgs.fms.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.dgs.fms.dto.DemoView;
import com.dgs.fms.dto.EmployeeMaster;
import com.dgs.fms.dto.FeedbackMaster;
import com.dgs.fms.exception.FMSException;
import com.dgs.fms.util.DBUtil;

public class FMSDaoImpl implements IFMSDao {

	Connection connection;
	PreparedStatement pstmt;
	Statement statement;
	ResultSet rst;
	EmployeeMaster emp;

	@Override
	public int insertFeedback(FeedbackMaster feedback) throws FMSException {
		connection = DBUtil.getConnection();
		int id = 0;
		try {
			pstmt = connection
					.prepareStatement("INSERT INTO FEEDBACKMASTER VALUES(?,?,?,?,?,?,?,?,?,sysdate)");
			pstmt.setInt(1, feedback.getTrainingCode());
			pstmt.setInt(2, feedback.getParticipantId());
			pstmt.setInt(3, feedback.getFbPrsComm());
			pstmt.setInt(4, feedback.getFbClrfyDbts());
			pstmt.setInt(5, feedback.getFbTm());
			pstmt.setInt(6, feedback.getFbHndOut());
			pstmt.setInt(7, feedback.getFbHwSwNtwrk());
			pstmt.setString(8, feedback.getComments());
			pstmt.setString(9, feedback.getSuggestions());

			id = pstmt.executeUpdate();
			System.out.println("Feedback Entered");
		} catch (SQLException e) {
			throw new FMSException(e.getMessage());
		}

		return id;

	}

	@Override
	public EmployeeMaster matchLogin(String employeeName) throws FMSException {
		
		System.out.println(employeeName);
		connection = DBUtil.getConnection();
		try {
			emp = new EmployeeMaster();
			String qry = "select employeeId,employeeName,password,role from employeeMaster where employeeName='"+employeeName+"'";
			
			//pstmt.setString(1, employeeName);
			pstmt=connection.prepareStatement(qry);
			
			rst = pstmt.executeQuery();
			if(rst.next())
			{
				emp.setEmployeeId(rst.getInt("employeeId"));
				emp.setEmployeeName(rst.getString("employeeName"));
				emp.setPassword(rst.getString("password"));
				emp.setRole(rst.getString("role"));
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return emp;
	}
	boolean a;

	@Override
	public List<DemoView> showMonthlyFeedback(String month) throws FMSException {
	
		List<DemoView> showFeedbackList = new ArrayList<DemoView>();
		try
		{
			connection = DBUtil.getConnection();
			statement = connection.createStatement();
			//String qry="select tp.startdate,cm.coursename,em.employeename,fm.fbPrsComm,fm.fbClrfyDbts,fm.fbTm,fm.fbHndOut,fm.fbHwSwNtwrk from Trainingprogram tp join coursemaster cm on tp.coursecode=cm.courseid join employeemaster em on em.employeeid=tp.facultycode join feedbackmaster fm on fm.participantId=em.employeeid";
			//rst = statement.executeQuery(qry);
			String qry="select * from demo_view where to_char( startdate,'mon') like'"+month+"'";
			rst = statement.executeQuery(qry);
			//to_char( tp.startdate, 'mm' ) 
			while(rst.next())
			{
				DemoView dv= new DemoView();
				
				dv.setStartDate(rst.getDate("startdate"));
				dv.setCourseName(rst.getString("coursename"));
				dv.setEmployeeName(rst.getString("employeename"));
				dv.setFbPrsComm(rst.getInt("fbPrsComm"));
				dv.setFbClrfyDbts(rst.getInt("fbClrfyDbts"));
				dv.setFbTm(rst.getInt("fbTm"));
				dv.setFbHndOut(rst.getInt("fbHndOut"));
				dv.setFbHwSwNw(rst.getInt("fbHwSwNtwrk"));
				
				
				
				showFeedbackList.add(dv);
			}
		}
		catch(SQLException e)
		{
			//e.printStackTrace();
			throw new FMSException("Something went wrong while fetching showMonthly feedback");
		}
		
		return showFeedbackList;
			}

}
