package com.dgs.fms.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;

import com.dgs.fms.dto.FeedbackMaster;
import com.dgs.fms.exception.FMSException;
import com.dgs.fms.util.DBUtil;

public class FMSDaoImpl  implements IFMSDao{

	
	
	
	
	@Override
	public int insertFeedback(FeedbackMaster feedback) throws FMSException {
		Connection con=DBUtil.getConnection();
		int id=0;
		try {
			PreparedStatement stat=con.prepareStatement("INSERT INTO FEEDBACKMASTER VALUES(?,?,?,?,?,?,?,?,?,sysdate)");
			stat.setInt(1, feedback.getTrainingCode());
			stat.setInt(2, feedback.getParticipantId());
			stat.setInt(3, feedback.getFbPrsComm());
			stat.setInt(4, feedback.getFbClrfyDbts());
			stat.setInt(5, feedback.getFbTm());
			stat.setInt(6, feedback.getFbHndOut());
			stat.setInt(7, feedback.getFbHwSwNtwrk());
			stat.setString(8, feedback.getComments());
			stat.setString(9, feedback.getSuggestions());
			
			id=stat.executeUpdate();
			System.out.println("entered feedback");
		} 
		catch (SQLException e) {
			throw new FMSException(e.getMessage());
		}
		
	return id;
		
	}
//	public List showMonthlyFeedback() throws FMSException 
//	{
////		List show = new ArrayList<ShowDetails>();
//		try
//		{
//			con = DBUtil.getConnection();
//			stm = con.createStatement();
//			res = stm.executeQuery("select * from shows");
//			while(res.next())
//			{
//				ShowDetails show = new ShowDetails() ;
//				show.setShowId(res.getString(1));
//				show.setShowName(res.getString(2));
//				show.setLocation(res.getString(3));
//				show.setShowDate(res.getDate(4));
//				show.setAvailableSeats(res.getInt(5));
//				show.setPrice(res.getDouble(6));
//				showDetailsList.add(show);
//			}
//		}
//		catch(SQLException e)
//		{
//			//e.printStackTrace();
//			throw new ShowException("Something went wrong while fetching showDetails");
//		}
//		finally
//		{
//			try 
//			{
//				res.close();
//				stm.close();
//				con.close();
//			} 
//			catch (SQLException e) 
//			{
//				//e.printStackTrace();
//				throw new ShowException("SQLException occurred");
//			}
//		}
//		return showDetailsList;

}
