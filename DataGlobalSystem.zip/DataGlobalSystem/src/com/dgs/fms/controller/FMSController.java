package com.dgs.fms.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.dgs.fms.dto.CourseMaster;
import com.dgs.fms.dto.DemoView;
import com.dgs.fms.dto.EmployeeMaster;
import com.dgs.fms.dto.FacultySkill;
import com.dgs.fms.dto.FacultySkillView;
import com.dgs.fms.dto.FeedbackMaster;
import com.dgs.fms.exception.FMSException;
import com.dgs.fms.service.FMSServiceImpl;
import com.dgs.fms.service.IFMSService;

/**
 * Servlet implementation class FMSController
 */
// @WebServlet("/SubmitFeedback")
@WebServlet("*.do")
public class FMSController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	IFMSService fmsService;
	EmployeeMaster emp;

	/**
	 * Default constructor.
	 */
	public FMSController() {
		fmsService = new FMSServiceImpl();
		emp = new EmployeeMaster();
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * javax.servlet.http.HttpServlet#doPost(javax.servlet.http.HttpServletRequest
	 * , javax.servlet.http.HttpServletResponse)
	 */
	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		FeedbackMaster feedback = new FeedbackMaster();
		// response.setContentType("text/html");
		// PrintWriter out=response.getWriter();
		String urlPattern = request.getServletPath();

		switch (urlPattern) {

		case "/SubmitFeedback.do":
			System.out.println("avhg");
			HttpSession session = request.getSession(true);

			int trainingCode = Integer.parseInt(request
					.getParameter("trainingcode"));
			int participantid = Integer.parseInt(request
					.getParameter("participantid"));
			int communicationskills = Integer.parseInt(request
					.getParameter("communicationskills"));
			int clarifydoubts = Integer.parseInt(request
					.getParameter("clarifydoubts"));
			int timemanagement = Integer.parseInt(request
					.getParameter("timemanagement"));
			int handouts = Integer.parseInt(request.getParameter("handouts"));
			int network = Integer.parseInt(request.getParameter("network"));
			String comments = request.getParameter("comments");
			String suggestions = request.getParameter("suggestions");

			try {

				feedback.setTrainingCode(trainingCode);
				feedback.setParticipantId(participantid);
				feedback.setFbPrsComm(communicationskills);
				feedback.setFbClrfyDbts(clarifydoubts);
				feedback.setFbTm(timemanagement);
				feedback.setFbHndOut(handouts);
				feedback.setFbHwSwNtwrk(network);
				feedback.setComments(comments);
				feedback.setSuggestions(suggestions);

				int i = fmsService.insertFeedback(feedback);
			} catch (FMSException e) {

				e.printStackTrace();
			}
			RequestDispatcher dispatch = request
					.getRequestDispatcher("FeedbackSuccess.jsp");
			dispatch.forward(request, response);

			break;

		case "/LoginMatch.do":
			session = request.getSession(true);
			String employeeName = request.getParameter("txtusername");
			// session.setAttribute("employee", employeeName);
			String url = "";
			String password = request.getParameter("txtpassword");
			String userType = request.getParameter("usertype");

			if (userType.equals("admin")) {
				url = "AdminHome.jsp";

			} else if (userType.equals("participant")) {
				url = "ParticipantHome.jsp";
			} else if (userType.equals("coordinator")) {
				url = "CoordinatorHome.jsp";
			}

			try {
				emp = fmsService.matchLogin(employeeName);
				if (employeeName.equals(emp.getEmployeeName())
						&& password.equals(emp.getPassword())
						&& userType.equals(emp.getRole())) {

					dispatch = request.getRequestDispatcher(url);
					dispatch.forward(request, response);
				} else {
					System.out.println("invalid username password");
					dispatch = request.getRequestDispatcher("Login.jsp");
					dispatch.include(request, response);
				}
			} catch (FMSException e) {
				e.printStackTrace();
			}

			break;

		case "/generateMonth.do":
			session = request.getSession(true);
			DemoView dv = new DemoView();
			String month = request.getParameter("month");
			try {
				List<DemoView> NewList = fmsService.showMonthlyFeedback(month);
				session.setAttribute("fbList", NewList);
				System.out.println(NewList);
			} catch (FMSException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			dispatch = request.getRequestDispatcher("MonthFeedback.jsp");
			dispatch.forward(request, response);
			break;

		case "/Defaulters.do":
			dispatch = request.getRequestDispatcher("Defaulters.jsp");
			dispatch.forward(request, response);
			break;
		case "/FacultyFeedback.do":
			dispatch = request.getRequestDispatcher("FacultyFeedback.jsp");
			dispatch.forward(request, response);
			break;

		case "/facultySkill.do":
			session = request.getSession(true);
			FacultySkillView mapFaculty = new FacultySkillView();

			List<FacultySkillView> faculty = new ArrayList<FacultySkillView>();
			try {
				faculty = fmsService.mapFacultySkills();
				session.setAttribute("faclist", faculty);
			} catch (FMSException e) {

				e.printStackTrace();
			}
			dispatch = request
					.getRequestDispatcher("FacultySkillMaintenance.jsp");
			dispatch.forward(request, response);

			break;
		case "/deleteFaculty.do":
			session = request.getSession(true);
			int id = Integer.parseInt(request.getParameter("id"));
			System.out.println(id);
			boolean flag = false;
			try {
				flag = fmsService.deleteFacultyRecord(id);
			} catch (FMSException e) {
				e.printStackTrace();
			}
			if (flag) {
				response.sendRedirect("facultySkill.do");
				response.setIntHeader("Refresh", 2);
			}
			break;

		case "/editFaculty.do":
			session = request.getSession(true);
			int idd = Integer.parseInt(request.getParameter("id"));
			String name = request.getParameter("name");
			String skillSet = request.getParameter("skillSet");
			session.setAttribute("facultyid", idd);
			session.setAttribute("facultyname", name);
			session.setAttribute("FacultySkill", skillSet);
			System.out.println(idd + " " + name + " " + skillSet);
			dispatch = request.getRequestDispatcher("EditFaculty.jsp");
			dispatch.forward(request, response);
			response.setIntHeader("Refresh", 2);

			break;

		case "/updateForm.do":
			session = request.getSession(true);
			FacultySkill fskill = new FacultySkill();
			int facultyiddd = Integer.parseInt(request
					.getParameter("facultyid"));
			String facultyname = request.getParameter("facultyname");
			String courselist = request.getParameter("courselist");
			session.setAttribute("facultyiddd", facultyiddd);
			session.setAttribute("facultyname", facultyname);
			session.setAttribute("courselist", courselist);

			System.out.println(facultyiddd + " " + facultyname + " "
					+ courselist);
			int facultyidd;
			try {
				facultyidd = fmsService.updateFacultySkill(courselist,
						facultyiddd);
			} catch (FMSException e) {

				e.printStackTrace();
			}

			response.sendRedirect("facultySkill.do");
			
			break;

		case "/CourseDetails.do":
			session = request.getSession(true);
			CourseMaster mapCourses = new CourseMaster();
			List<CourseMaster> coursesView = new ArrayList<CourseMaster>();
			try {
				coursesView = fmsService.mapCourseSkills();
				session.setAttribute("Courses", coursesView);
			} catch (FMSException e) {

				e.printStackTrace();
			}
			dispatch = request.getRequestDispatcher("CourseDetails.jsp");
			dispatch.forward(request, response);

			break;

		case "/editCourseDetails.do":
			session = request.getSession(true);
			int courseid = Integer.parseInt(request.getParameter("id"));
			String coursename = request.getParameter("name");
			String noofdays = request.getParameter("noofcourses");
			session.setAttribute("courseid", courseid);
			session.setAttribute("coursename", coursename);
			session.setAttribute("noofdays", noofdays);
			System.out.println(courseid + " " + coursename + " " + noofdays);
		
		    dispatch = request.getRequestDispatcher("EditCourseDetails.jsp");
	        dispatch.forward(request, response);
			response.setIntHeader("Refresh", 2);
			break;

		case "/AddCourses.do":
			session = request.getSession(true);
			String courseName = request.getParameter("coursename");
			int noOfdays = Integer.parseInt(request.getParameter("noofdays"));
			int add;
			session.setAttribute("courseName", courseName);
			session.setAttribute("noOfdays", noOfdays);
			CourseMaster courseM = new CourseMaster();
			courseM.setCourseName(courseName);
			courseM.setNoOfDays(noOfdays);
			
			try {
				add = fmsService.insertCourseRecord(courseName,noOfdays);
			} catch (FMSException e) {
				e.printStackTrace();
			}

			response.sendRedirect("CourseDetails.do");
			break;
		  case "/ForgetPassword.do":
			break;
			
		  case "/updateCourses.do":
				session = request.getSession(true);
				CourseMaster cmaster=new CourseMaster();
				int courseidd = Integer.parseInt(request.getParameter("courseid"));
				String coursenames = request.getParameter("coursename");
				int noofdayss = Integer.parseInt(request.getParameter("noofdays"));
				session.setAttribute("courseidd", courseidd);
				session.setAttribute("noofdayss", noofdayss);
				session.setAttribute("noofdayss", noofdayss);

				int courseiddd=0;
			try {
				courseiddd = fmsService.updateCourseList(courseidd, noofdayss);
			} catch (FMSException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
				response.sendRedirect("CourseDetails.do");
				break;
		}
	}
}
