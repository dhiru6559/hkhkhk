package com.dgs.fms.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.dgs.fms.dto.FeedbackMaster;
import com.dgs.fms.exception.FMSException;
import com.dgs.fms.service.FMSServiceImpl;
import com.dgs.fms.service.IFMSService;

/**
 * Servlet implementation class FMSController
 */
//@WebServlet("/SubmitFeedback")
@WebServlet("*.do")
public class FMSController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	IFMSService fmsService;
    /**
     * Default constructor. 
     */
    public FMSController() {
    	fmsService=new FMSServiceImpl();
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request,response);
	}
	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		System.out.println("abghjhhj");
		FeedbackMaster feedback=new FeedbackMaster();
		//response.setContentType("text/html");
		//PrintWriter out=response.getWriter();
		String urlPattern=request.getServletPath();

		
		switch(urlPattern){
		
		case "/SubmitFeedback.do":
			System.out.println("avhg");
			HttpSession session =request.getSession(true);
			
			int trainingCode= Integer.parseInt(request.getParameter("trainingcode"));
			int participantid=Integer.parseInt(request.getParameter("participantid"));
			int communicationskills=Integer.parseInt(request.getParameter("communicationskills"));
			int clarifydoubts=Integer.parseInt(request.getParameter("clarifydoubts"));
			int timemanagement=Integer.parseInt(request.getParameter("timemanagement"));
			int handouts=Integer.parseInt(request.getParameter("handouts"));
			int network=Integer.parseInt(request.getParameter("network"));
			String comments=request.getParameter("comments");
			String suggestions=request.getParameter("suggestions");
			
			try {
				
				feedback.setTrainingCode(trainingCode);
				feedback.setParticipantId(participantid);
				feedback.setFbPrsComm(communicationskills);
				feedback.setFbClrfyDbts(clarifydoubts);
				feedback.setFbTm(timemanagement);
				feedback.setFbHndOut(handouts);
				feedback.setFbHwSwNtwrk(network);
				feedback.setComments(comments);
				feedback.setSuggestions(suggestions);
			
				
				int i=fmsService.insertFeedback(feedback);
			} catch (FMSException e) {
				
				e.printStackTrace();
			}
			RequestDispatcher dispatch=request.getRequestDispatcher("FeedbackSuccess.jsp");
			dispatch.forward(request, response);
			
		}
		
		
	}
	}

