package com.capgemini.core.busbooking.ui;

import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import org.apache.log4j.PropertyConfigurator;

import com.capgemini.core.busbooking.dto.BookingDetails;
import com.capgemini.core.busbooking.dto.BusSchedule;
import com.capgemini.core.busbooking.exception.BusBookingException;
import com.capgemini.core.busbooking.service.BusBookingServiceImpl;
import com.capgemini.core.busbooking.service.IBusBookingService;
import com.capgemini.core.busbooking.util.ValidationUtil;

interface MenuOptions
{
	int VIEW_BUS_SCHEDULE = 1;
	int BOOK_A_BUS = 2;
	int EXIT_APPLICATION = 3;
}

public class BusBookingUI implements MenuOptions
{
	private IBusBookingService busBookingService;
	
	public BusBookingUI() {
		busBookingService = new BusBookingServiceImpl();
	}

	public void menu()
	{
		Scanner console = new Scanner(System.in);
		
		System.out.println("\n\n1) View Bus Schedule");
		System.out.println("2) Book A Bus");
		System.out.println("3) Exit");
		
		System.out.print("Select an option:");
		int choice = console.nextInt();
		
		switch ( choice ) 
		{
			case VIEW_BUS_SCHEDULE: viewBusSchedule(); break;
			case BOOK_A_BUS: bookABus(); break;
			case EXIT_APPLICATION: 
				System.out.println("Good Bye");
				System.exit(0);
			break;

			default: System.out.println("You have selected invalid operation");	break;
		}	
	}

	private void viewBusSchedule() 
	{
		try 
		{
			List<BusSchedule> busSchedule = busBookingService.getBusSchedule();
			
			System.out.println("Bus ID \t Bus Name \t Start Location \t End Location \tTimings \tAvailable Seat Count");
			
			Iterator<BusSchedule> it = busSchedule.iterator();
			
			while(it.hasNext())
			{
				BusSchedule busSch =  it.next();
				
				System.out.println( busSch.getBusId() + "\t" + 
						busSch.getName() + "\t" + 
						busSch.getStartLocation() + "\t" + 
						busSch.getEndLocation() + "\t" + 
						busSch.getTiming() + "\t" + 
						busSch.getNoOfAvailableSeats() );
			}				
		} 	
		catch (BusBookingException e) 
		{
			System.out.println("Something went wrong while trying to fetch bus schedule. Reason: " + e.getMessage());
		}
		
	}

	private void bookABus() 
	{
		Scanner console = new Scanner(System.in);
		
		String name = null;
		
		do{
			System.out.print("Enter Customer Name: ");
			name = console.nextLine();
			
		}while( ValidationUtil.isCustomerNameInvalid(name));
		
		int busId = 0;
		
		do 
		{
			System.out.print("Enter Bus ID: ");
			busId = console.nextInt();
			
		} while ( ValidationUtil.isBusIdInvalid(busId));
		
		int noOfRequestedSeats = 0;
				
		do 
		{
			System.out.print("Enter Desired number of Seats to Book: ");
			noOfRequestedSeats = console.nextInt();
			
		} while (ValidationUtil.isNoOfRequestedSeatsInvalid( noOfRequestedSeats ) );
		
		BookingDetails bookingDetails = 
				new BookingDetails(name, noOfRequestedSeats, busId);
		
		try 
		{
			int bookingId = busBookingService.bookABus( bookingDetails );
			
			System.out.println("Booking successful. Booking ID " + bookingId);
		} 
		catch (BusBookingException e) 
		{
			System.out.println("Something went wrong while trying to book a Bus. Reason: "+ e.getMessage());;
		}
	}
	
	public static void main(String[] args) 
	{
		PropertyConfigurator.configure("log4j.properties");
		
		BusBookingUI ui = new BusBookingUI();
		
		while(true)
		{
			ui.menu();
		}
	}
}















