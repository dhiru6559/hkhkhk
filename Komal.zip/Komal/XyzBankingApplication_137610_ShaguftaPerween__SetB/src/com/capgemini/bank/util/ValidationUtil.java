package com.capgemini.bank.util;

import java.util.regex.Matcher;
import java.util.regex.Pattern;


public class ValidationUtil {

	public static boolean isNameInvalid(String name) {
		
		 Pattern p1=Pattern.compile("[a-z\\s]{1,19}$");
		Matcher m1=p1.matcher(name);
		if(!m1.find()){
			return true;
			
		}
		 
		return false;
	}

	public static boolean isphoneInvalid(String phone) {
		
		Pattern p1=Pattern.compile("^[7-9]{1}[0-9]{9}$");
		Matcher m1=p1.matcher(phone);
		if(!m1.find()){
			return true;
			
		}
		return false;
	}

	public static boolean isfavorInvalid(String favor) {
		 Pattern p1=Pattern.compile("^[a-z\\s]{1,19}$");
			Matcher m1=p1.matcher(favor);
			if(!m1.find()){
				return true;
			}
		return false;
	}

	public static boolean isddAmountInvalid(int ddAmount) {
		 Pattern p1=Pattern.compile("^[1-9]{1}[0-9]{1,}$");
			Matcher m1=p1.matcher(ddAmount+"");
			if(!m1.find()){
				return true;
			}
		return false;
	}

	public static boolean isRemarksInvalid(String remarks) {
		 Pattern p1=Pattern.compile("^[a-z\\s]{1,19}$");
			Matcher m1=p1.matcher(remarks);
			if(!m1.find()){
				return true;
			}
		return false;
	}

	
	
}
