package com.capgemini.bank.bean;

import java.sql.Date;

public class DemandDraft {
		

		private int transactionId;
		private String cname;
		private String inFavorOf;
		private String phNo;
		private Date date;
		private int amount;
		private int commission;
		private String description;

		
		public DemandDraft() {
			super();
		}
		public DemandDraft(String cname, String inFavorOf, String phNo, Date date, int amount, int commission,
				String description) {
			super();
			this.cname = cname;
			this.inFavorOf = inFavorOf;
			this.phNo = phNo;
			this.date = date;
			this.amount = amount;
			this.commission = commission;
			this.description = description;
		}

		public DemandDraft(int transactionId, String cname, String inFavorOf, String phNo, Date date, int amount,
				int commission, String description) {
			super();
			this.transactionId = transactionId;
			this.cname = cname;
			this.inFavorOf = inFavorOf;
			this.phNo = phNo;
			this.date = date;
			this.amount = amount;
			this.commission = commission;
			this.description = description;
		}

		public DemandDraft(String cname, String inFavorOf, String phNo, int amount, int commission, String description) {
			super();
			this.cname = cname;
			this.inFavorOf = inFavorOf;
			this.phNo = phNo;
			this.amount = amount;
			this.commission = commission;
			this.description = description;
		}
		public int getTransactionId() {
			return transactionId;
		}

		public void setTransactionId(int transactionId) {
			this.transactionId = transactionId;
		}

		public String getCname() {
			return cname;
		}

		public void setCname(String cname) {
			this.cname = cname;
		}

		public String getInFavorOf() {
			return inFavorOf;
		}

		public void setInFavorOf(String inFavorOf) {
			this.inFavorOf = inFavorOf;
		}

		public String getPhNo() {
			return phNo;
		}

		public void setPhNo(String phNo) {
			this.phNo = phNo;
		}

		public Date getDate() {
			return date;
		}

		public void setDate(Date curdate) {
			this.date = curdate;
		}

		public int getAmount() {
			return amount;
		}

		public void setAmount(int amount) {
			this.amount = amount;
		}

		public int getCommission() {
			return commission;
		}

		public void setCommission(int commission) {
			this.commission = commission;
		}

		public String getDescription() {
			return description;
		}

		public void setDescription(String description) {
			this.description = description;
		}

	

}
