package com.capgemini.bank.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import org.apache.log4j.Logger;

import com.capgemini.bank.Exception.BankException;
import com.capgemini.bank.bean.DemandDraft;
import com.capgemini.bank.util.DBUtil;


public class DemandDraftDAO implements IDemandDraftDAO {

	static Logger myLogger=Logger.getLogger(DemandDraftDAO.class.getName());

	/*
	 * Author: Shagufta Perween
	 * EmpID: 137610
	 * Date: 26th oct 2017
	 * Description: Entering Demand Draft details
	 */
	
	
	
	@Override
	public int addDemandDraftDetails(DemandDraft demandDraft) throws BankException {

		myLogger.info("inserting demand draft details into demand_draft table");
		myLogger.debug("Trying to enter demand draft details");	
		int id = 0;
		try (Connection con = DBUtil.getConnection()) {
			PreparedStatement pstm = con.prepareStatement("insert into demand_draft values(?,?,?,?,sysdate,?,?,?)");

		
			
			demandDraft.setTransactionId(generateTransactionId());
			pstm.setInt(1, demandDraft.getTransactionId());
			pstm.setString(2, demandDraft.getCname());
			pstm.setString(3, demandDraft.getInFavorOf());
			pstm.setString(4, demandDraft.getPhNo());
			pstm.setInt(5, demandDraft.getAmount());
			pstm.setInt(6, demandDraft.getCommission());
			pstm.setString(7, demandDraft.getDescription());

			pstm.execute();

			id = demandDraft.getTransactionId();

		} catch (Exception e) {

			throw new BankException(e.getMessage());
		}
		return id;
	}

	private int generateTransactionId() throws BankException {
		

		myLogger.info("generate id methods started");
		myLogger.debug("Trying to generate emp id from sequence");	

		int id = 0;

		try (Connection con = DBUtil.getConnection()) {

			Statement stn = con.createStatement();
			ResultSet res = stn.executeQuery("select Transaction_id_seq.nextval from dual");
			if (res.next() == false) {

				throw new Exception("Could not generate id");

			}
			id = res.getInt(1);
		} catch (Exception e) {
			myLogger.error("Sequence not generated");
			throw new BankException(e.getMessage());
		}
		return id;
	}

	@Override
	public DemandDraft getDemandDraftDetails(int transactionId) throws BankException {

		DemandDraft demandDraft = null;

		try (Connection con = DBUtil.getConnection()) {

			PreparedStatement pstm = con.prepareStatement("select * from demand_draft where transaction_id=? ");
			pstm.setInt(1, transactionId);
			ResultSet rs = pstm.executeQuery();

			if (rs.next() == false)
				throw new Exception("Invalid Transaction Id");

			demandDraft = new DemandDraft();

			demandDraft.setTransactionId(transactionId);
			demandDraft.setCname(rs.getString(2));
			demandDraft.setInFavorOf(rs.getString(3));
			demandDraft.setPhNo(rs.getString(4));
			demandDraft.setDate(rs.getDate(5));
			demandDraft.setAmount(rs.getInt(6));
			demandDraft.setCommission(rs.getInt(7));
			demandDraft.setDescription(rs.getString(8));

		} catch (Exception e) {

			throw new BankException(e.getMessage());

		}
		return demandDraft;

	}
}
