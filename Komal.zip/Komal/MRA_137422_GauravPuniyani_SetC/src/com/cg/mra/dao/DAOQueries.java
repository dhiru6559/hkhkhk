package com.cg.mra.dao;

//================================================================================================================

	/*
	 * Author: Gaurav Puniyani
	 * Emp ID: 137422	
	 * Date: 26th Oct 2017
	 * Description: Account DAO SQL Queries
	 */

	
//=================================================================================================================



public interface DAOQueries {
	
	public static String RECHARGE_AMOUNT = "update account set ACC_BALANCE = ACC_BALANCE + ? where ACCOUNT_ID = ?";
	public static String GET_ACCOUNT_DETAILS = "select * from ACCOUNT where ACCOUNT_ID =?";

}
