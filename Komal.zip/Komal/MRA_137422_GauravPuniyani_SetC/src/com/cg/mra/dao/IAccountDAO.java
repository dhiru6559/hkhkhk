package com.cg.mra.dao;

import com.cg.mra.dto.Account;
import com.cg.mra.exception.AccountException;


public interface IAccountDAO {

	public Account getAccountDetails(String accountId) throws AccountException;
	
	public int rechargeAccount(String accountId, double rechargeAmount) throws AccountException;
}
