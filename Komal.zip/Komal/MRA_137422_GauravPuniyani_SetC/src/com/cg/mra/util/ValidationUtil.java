package com.cg.mra.util;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

//================================================================================================================

	/*
	 * Author: Gaurav Puniyani
	 * Emp ID: 137422	
	 * Date: 26th Oct 2017
	 * Description: Account Validation
	 */

	
//=================================================================================================================


public class ValidationUtil {

	public static boolean isAccountIdInvalid(String accountId) {
		Pattern pattern = Pattern.compile("[0-9]");
		Matcher matcher = pattern.matcher(accountId + "");
		if (matcher.find())
			return false;
		return true;
	}

//	public static boolean isAccountTypeInvalid(String accountType) {
//		Pattern pattern = Pattern.compile("^[a-zA-Z]{20}$");
//		Matcher matcher = pattern.matcher(accountType + "");
//		if (matcher.find())
//			return false;
//		return true;
//	}
//
//	public static boolean isCustomerNameInvalid(String customerName) {
//		Pattern pattern = Pattern.compile("^[A-Za-z]{20}$");
//		Matcher matcher = pattern.matcher(customerName);
//		if (matcher.find())
//			return false;
//		return true;
//	}


	public static boolean isAccountBalanceInvalid(double accountBalance) {
		if (accountBalance >= 0)
			return false;
		return true;
	}
}
