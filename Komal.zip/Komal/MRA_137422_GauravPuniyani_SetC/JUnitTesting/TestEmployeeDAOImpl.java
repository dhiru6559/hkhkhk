package JUnitTesting;

import static org.junit.Assert.*;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;

import com.capgemini.core.ems.dto.Employee;
import com.capgemini.core.ems.exception.EmployeeException;
import com.capgemini.core.ems.service.EmployeeServiceImpl;
import com.capgemini.core.ems.service.IEmployeeService;

public class TestEmployeeDAOImpl {

	static IEmployeeService employeeService;
	
	@BeforeClass
	public static void init(){
		employeeService = new EmployeeServiceImpl();
	}
	
	@AfterClass
	public static void destroy(){
		employeeService = null;
		System.gc();
	}
	
	
	@Test
	public void testAddEmployee() {
		Employee emp = new Employee("Test",1200, "Test", "Test");
		
		int id = 0;
		
		try 
		{
			id = employeeService.addEmployee(emp);
			
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
		}
		
		assertNotEquals(0, id);
	}


	@Test(expected = EmployeeException.class)
	public void testRemoveEmployee() throws EmployeeException 
	{
			employeeService.removeEmployee(354542);
		
	}

}
