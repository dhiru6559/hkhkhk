package com.cg.frs.dbutil;

import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

public class dbUtil {
	public static Connection getConnection() throws IOException, SQLException {
		Connection con = null;      //creation of connection
		Properties prop = readDbInfo();
		String url = prop.getProperty("url");  //getting url
		String username = prop.getProperty("username");      //getting username
		String password = prop.getProperty("password");     //getting password
		con = DriverManager.getConnection(url, username, password);
		return con;

	}

	private static Properties readDbInfo() throws IOException {
		Properties p = new Properties();
		FileReader fr = new FileReader("dbUtil.properties");
		p.load(fr);
		return p;
	}

}
