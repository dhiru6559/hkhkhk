package com.cg.frs.ui;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Scanner;

import com.cg.frs.dto.FLatRegistrationDTO;
import com.cg.frs.exception.FlatRegServiceException;
import com.cg.frs.service.FlatRegistrationServiceImpl;
import com.cg.frs.service.IFlatRegistrationService;

public class Client {
	// scanner class is declared
	static Scanner sc = new Scanner(System.in);
	// service object is created
	static IFlatRegistrationService service = new FlatRegistrationServiceImpl();

	// main class
	public static void main(String[] args) throws SQLException,
			FlatRegServiceException, IOException {
		while (true) {
			// user interface
			System.out.println("1.Register flat");
			System.out.println("2.Exit");
			int choice = sc.nextInt();
			switch (choice) {
			case 1:
				registerFlats();
				break;
			case 2:
				return;

			}
		}
	}

	// methods being implemented
	private static void registerFlats() throws SQLException,
			FlatRegServiceException {
		int result = 0;
		try {
			// inputs being taken from the user
			System.out.println("Existing Owner IDs Are:-");
			ArrayList<Integer> list = new ArrayList<Integer>();
			list = service.getAllOwnerIds();
			System.out.println(list);
			System.out.println("\nPlease enter your owner id from above list:");
			int oid = sc.nextInt();
			System.out.println("\nSelect Flat Type(1-1BHK,2-2BHK)");
			int flatType = sc.nextInt();
			System.out.println("\nEnter Flat Area in sq.ft.:");
			int flatArea = sc.nextInt();
			System.out.println("\nEnter desired rent amount RS:");
			int rentAmt = sc.nextInt();
			System.out.println("\nEnter desired deposit amount Rs:");
			int depositAmt = sc.nextInt();
			// object of flat registration is made
			FLatRegistrationDTO flatRegistration = new FLatRegistrationDTO(oid,
					flatType, flatArea, rentAmt, depositAmt);
			// to check the validations are validated or not ..calling is done
			if (service.isValidDetails(flatRegistration))
				;
			result = service.registerFlat(flatRegistration);
		} catch (FlatRegServiceException | SQLException | IOException e) {

			System.out.println("errors  ===> " + e.getMessage());// message is
																	// printed
																	// in case
																	// the
																	// validations
																	// are
																	// incorrect
		}
		// if result is other than 0 then the values are inserted
		if (result == 1) {
			System.out.println("values are inserted");
		} else {
			System.out.println("not inserted");
		}

	}

}
