package com.test;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

public class TestSerial2 {
	public static void main(String[] args) {
		Employee obj=new Employee(100,"Shyam",45651);
		try {
			
			
			FileInputStream fin=new FileInputStream("emp.dat");
			ObjectInputStream oin=new ObjectInputStream(fin);
			
			Employee emp=(Employee)oin.readObject();
			System.out.println(emp.toString());
			oin.close();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}}
