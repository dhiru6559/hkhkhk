package com.test;

import java.io.File;

public class TestFile1 {

	public static void main(String[] args) {
		//String str="sample1.txt";
		String str="c:/dk";
		File file=new File(str);
		//if(file.exists() && file.isFile()){
		if(file.exists()&&file.isDirectory()){
		//System.out.println("Is a Directory");
			//System.out.println("Length ="+file.length());
			String listOfFiles[]=file.list();
				for(String fileName:listOfFiles){
					System.out.println(fileName);
				}
		}
		else
			System.out.println("Not A Directory");
	}

}
