package com.test;

import java.io.BufferedOutputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class TestBuffer {

	public static void main(String[] args) {
		
		try {
			FileOutputStream fout=new FileOutputStream("testbuf.txt");
			BufferedOutputStream buffer=new BufferedOutputStream(fout);
			long start=System.currentTimeMillis();
	
			for(int i=0;i<10000000;++i){
				//buffer.write(65);
				fout.write(65);
			}
			long stop=System.currentTimeMillis();
			buffer.close();
			System.out.println("Buffer Write Complete"+(stop-start));
			fout.close();
		} catch (FileNotFoundException e) {
			System.out.println("File Not Found");
			e.printStackTrace();
		} catch (IOException e) {
			
			e.printStackTrace();
		}
	}

}
