package com.test;

import java.io.FileOutputStream;
import java.io.FileReader;
import java.util.Properties;

public class ReadPropertyFile {

	public static void main(String[] args) throws Exception {
		
		Properties props=new Properties();
		//FileReader fr=new FileReader("logininfo.properties");
		props.load(new FileReader("logininfo.properties"));
		
		String user=props.getProperty("username");
		String pass=props.getProperty("password");
		System.out.println("USERNAme/"+user);
		System.out.println("Password/"+pass);
		props.setProperty("usermobile", "9812700994");
		FileOutputStream fout=new FileOutputStream("test.properties");
		props.store(fout, "Added Key value pair");
		props.list(System.out);
	}

}
