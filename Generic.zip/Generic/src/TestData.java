
public class TestData {
	
	public static void main(String[] args) {
		Data<Integer> obj1=new Data<Integer>();
		Data<String> obj2=new Data<String>();
		
		Data<Employee> obj3=new Data<Employee>();
		obj3.setData(new Employee(121,"Anku",1500));
		Employee employee=obj3.getData();
		System.out.println(employee);
		
	//	obj3.getData();
		
		obj1.setData(100);
		int i=obj1.getData();
		System.out.println(i);
		
		obj2.setData("Dheeraj");
		String s=obj2.getData();
		System.out.println(s);
	}
}
