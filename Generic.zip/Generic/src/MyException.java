
public class MyException extends Exception{

	public MyException(String string) {
		super();
		
	}
	
	
}
