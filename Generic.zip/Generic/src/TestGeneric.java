import java.util.ArrayList;
import java.util.List;


public class TestGeneric {
	
	public static List<String> getAllElements(List<String> list){
		ArrayList<String> mylist=new ArrayList<String>();
		for(String str:list){
			mylist.add(str);
		}
		return(mylist);
	}
	
	
	public static void printLastElement(List<String> list) throws MyException
	{
			if(list!=null && list.size()>0){
			int n=list.size()-1;
			String str=list.get(n);
			System.out.println(str);}
			else
				throw new MyException("List is empty");
	}

	public static void main(String[] args) {
		//List<string> list=Array.asList("one","two","three");
		ArrayList<String> list=null;//new ArrayList<String>();
		list.add("one");
		list.add("two");
		list.add("three");
		
		try {
			printLastElement(list);
		} catch (MyException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		//String str=list.get(list.size()-1);
		//list.forEach(p->System.out.println(p));
		
	/*	for(String s:list){
			System.out.println(s);
		} */
		List<String> nlist=getAllElements(list);
		for(String str: nlist){
			System.out.println(str);
		}

	}

}
