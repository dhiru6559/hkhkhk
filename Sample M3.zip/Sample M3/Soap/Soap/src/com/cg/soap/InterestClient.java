package com.cg.soap;

import java.net.URL;
import java.util.Scanner;
import javax.xml.namespace.QName;
import javax.xml.ws.Service;

public class InterestClient {

public static void main(String[] args) throws Exception {
// TODO Auto-generated method stub
URL url = new URL("http://localhost:8090/is?wsdl");

// Qualified name of the service:
// 1st arg is the service URI
// 2nd is the service name published in the WSDL
// See WSDL file to see both parameters
// by default 'Service' is added in Implementation class
QName qname = new QName("http://soap.cg.com/", "InterestServiceImplService");

// Create, in effect, a factory for the service.
Service service = Service.create(url, qname);

// Extract the endpoint interface, the service "port".
InterestService endPointIntf = service.getPort(InterestService.class);
double rate = 0, time = 0, principal = 0;
Scanner sc = new Scanner(System.in);
System.out.println("Enter principle ");
principal = sc.nextDouble();
System.out.println("Enter rate");
rate = sc.nextDouble();
System.out.println("Enter time");
time = sc.nextDouble();
double cmpInt = endPointIntf.compoundInterest(principal, rate, time);
System.out.printf("\nThe Compound Intrest is : Rs%10.2f ", +(cmpInt));
double siInt = endPointIntf.simpleIntrest(principal, rate, time);
System.out.printf("\nThe Simple   Intrest is : Rs%10.2f ", +(siInt));
System.out.printf("\nThe Difference       is : Rs%10.2f ", +(cmpInt - siInt));
}

}