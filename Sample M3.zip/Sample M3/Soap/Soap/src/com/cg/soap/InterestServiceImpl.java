package com.cg.soap;

import javax.jws.WebService;

@WebService(endpointInterface = "com.cg.soap.InterestService")
public class InterestServiceImpl implements InterestService {

@Override
public double compoundInterest(double principle, double rate, double time) {
// TODO Auto-generated method stub
// BL
double amount = 0, ci, t = 1;
rate = (1 + rate / 100);
for (int i = 0; i < time; i++)
t *= rate;
amount = principle * t;
ci = amount - principle;
return ci;
}

@Override
public double simpleIntrest(double principle, double rate, double time) {
// TODO Auto-generated method stub
double amount = 0, si = 0;
si = (principle * rate * time) / 100;
return si;
}

}