package com.cg.soap;

import javax.xml.ws.Endpoint;

public class InterestPublisher {

public static void main(String[] args) {
// TODO Auto-generated method stub
/**
* public static Endpoint publish(String address, Object implementor)
* Creates and publishes an endpoint for the specified implementor
* object at the given address. The necessary server infrastructure will
* be created and configured by the JAX-WS implementation using some
* default configuration
* 
*/
Endpoint.publish("http://127.0.0.1:8090/is", new InterestServiceImpl());
System.out.println("Web Service Published.... ");

}

}