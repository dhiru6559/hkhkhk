package fastfood;

import java.awt.*;
import javax.swing.*;
import java.util.Vector;
import javax.swing.table.DefaultTableModel;
import java.sql.*;
import java.awt.event.MouseListener;
import java.awt.event.MouseEvent;
import javax.swing.JPanel;
import java.io.*;

public class MyPanel extends JPanel implements MouseListener {

    JButton bPrintBill, bShow, bCustomer;
    JTextField tBillNo, tBTax, tTotal, tGrandTotal, tCID;
    DefaultTableModel mBillDetails, mCustomers;
    JTable tBillDetails, tCustomers;

    public MyPanel() {
        setLayout(null);

        JLabel lBillNo = new JLabel("Bill No.");
        lBillNo.setBounds(10, 20, 100, 30);
        add(lBillNo);

        tBillNo = new JTextField("");
        tBillNo.setBounds(120, 20, 200, 30);
        add(tBillNo);

        JLabel lCID = new JLabel("Customer ID");
        lCID.setBounds(10, 70, 100, 30);
        add(lCID);

        tCID = new JTextField("");
        tCID.setBounds(120, 70, 200, 30);
        add(tCID);
        
        ImageIcon billImage = new ImageIcon("images/showBills.png");
        bShow = new JButton("Show Bill", billImage);
        bShow.setBounds(10, 120, 150, 50);
        add(bShow);
        
        ImageIcon printImage = new ImageIcon("images/print.png");
        bPrintBill = new JButton("Print Bill", printImage);
        bPrintBill.setBounds(170, 120, 150, 50);
        add(bPrintBill);
        
        ImageIcon customerImage = new ImageIcon("images/customer.png");
        bCustomer = new JButton("Customer Details",customerImage);
        bCustomer.setBounds(60, 200, 200, 50);
        add(bCustomer);

        String heads1[] = {"BillNo ", "Date", "Tax", "SNo.", "CID", "PID", "MRP", "Quantity", "SubTotal"};
        mBillDetails = new DefaultTableModel(heads1, 0);
        tBillDetails = new JTable(mBillDetails);
        JScrollPane jspBillDetails = new JScrollPane(tBillDetails);
        jspBillDetails.setBounds(400, 10, 900, 200);
        add(jspBillDetails);

        String heads[] = {"Customer ID", "Name", "Email Id", "Contact No", "Address"};
        mCustomers = new DefaultTableModel(heads, 0);
        tCustomers = new JTable(mCustomers);
        JScrollPane jspCustomer = new JScrollPane(tCustomers);
        jspCustomer.setBounds(400, 360, 900, 200);
        add(jspCustomer);

        JLabel lBTax = new JLabel("TAX");
        lBTax.setBounds(1050, 230, 100, 30);
        add(lBTax);

        tBTax = new JTextField("");
        tBTax.setBounds(1100, 230, 100, 30);
        add(tBTax);

        JLabel lTotal = new JLabel("Total");
        lTotal.setBounds(1050, 280, 100, 30);
        add(lTotal);

        tTotal = new JTextField("");
        tTotal.setBounds(1100, 280, 100, 30);
        add(tTotal);

        JLabel lGrandTotal = new JLabel(" Grand Total");
        lGrandTotal.setBounds(1000, 320, 100, 30);
        add(lGrandTotal);

        tGrandTotal = new JTextField("");
        tGrandTotal.setBounds(1100, 320, 100, 30);
        add(tGrandTotal);

        bPrintBill.addActionListener(e -> printBill());
        bShow.addActionListener(e -> {

            showBills();
            totalBill();
            grandtotal();
        });
        bCustomer.addActionListener(e -> fillCustomers());
        //bShow.addActionListener(e ->{fillCustomers();particularBillDetails();});
        tBillDetails.addMouseListener(this);

    }

    public void fillCustomers() {
        removeCustomers();
        try {
            int row = tBillDetails.getSelectedRow();
            Connection con = Data.getConnection();
            PreparedStatement ps = con.prepareStatement("select Customers.CID,Customers.Name,Customers.EmailId,Customers.ContactNo,Customers.Address from  Customers inner join Bill_Details on Customers.CID=Bill_Details.CID where Bill_Details.CID=?");
            // ps.setInt(1,Integer.parseInt(mBillDetails.getValueAt(row,4).toString()));
            ps.setInt(1, Integer.parseInt(tCID.getText()));
            ResultSet rs = ps.executeQuery();
            Vector<Object> v;
            while (rs.next()) {
                v = new Vector<Object>();
                v.add(rs.getInt(1));
                v.add(rs.getString(2));
                v.add(rs.getString(3));
                v.add(rs.getString(4));
                v.add(rs.getString(5));
                mCustomers.addRow(v);

            }
            con.close();

        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, ex.toString());
        }
    }

    public void particularBillDetails() {
        removeAllBills();

        try {
            Connection con = Data.getConnection();
            PreparedStatement ps = con.prepareStatement("Select Bill_Info.BillNo,Bill_Info.BillDate,Bill_Info.Tax,Bill_Details.SNo,Bill_Details.CID,Bill_Details.PID,Bill_Details.Price,Bill_Details.Quantity,Bill_Details.Price*Bill_Details.Quantity as subtotal from Bill_Info,Bill_Details where Bill_Info.BillNo=?");
            ps.setInt(1, Integer.parseInt(tBillNo.getText()));
            ResultSet rs = ps.executeQuery();
            Vector<Object> v;
            while (rs.next()) {
                v = new Vector<Object>();
                v.add(rs.getInt(1));
                v.add(rs.getString(2));
                v.add(rs.getInt(3));
                v.add(rs.getInt(4));
                v.add(rs.getInt(5));
                v.add(rs.getInt(6));
                v.add(rs.getInt(7));
                v.add(rs.getInt(8));
                v.add(rs.getInt(9));

                mBillDetails.addRow(v);
            }
            con.close();
        } catch (Exception ex) {

        }

    }

    public boolean isBillNoExist(String billNo) {
        try {
            Connection con = Data.getConnection();
            PreparedStatement ps = con.prepareStatement("Select count(BillNo) from Bill_Info where BillNo=?");
            ps.setInt(1, Integer.parseInt(billNo));
            ResultSet rs = ps.executeQuery();
            boolean flag = rs.next();
            con.close();
            return flag;
        } catch (Exception ex) {
            //JOptionPane.showMessageDialog(c, ex.toString());
            return false;
        }

    }

    public void showBills() {

        if (tBillNo.getText().isEmpty()) {
            System.out.println("Enter Bill No.");
            return;
        }
        try {

            boolean b = isBillNoExist((tBillNo.getText()));
            if (b) {
                particularBillDetails();
            }
        } catch (Exception ex) {

        }

    }

    public void totalBill() {
        try {

            int sum = 0, tax = 0;

            for (int i = 0; i < mBillDetails.getRowCount(); ++i) {
                String str = (String.valueOf(mBillDetails.getValueAt(i, 8)));
                sum = sum + Integer.parseInt(str);
                tax = sum * 24 / 100;
            }
            tTotal.setText(String.valueOf(sum));
            tBTax.setText(String.valueOf(tax));
        } catch (Exception ex) {
            //JOptionPane.showMessageDialog(c, ex.toString());

        }
    }

    public void grandtotal() {
        int grandtotal = Integer.parseInt(tTotal.getText()) + Integer.parseInt(tBTax.getText());
        tGrandTotal.setText(String.valueOf(grandtotal));
    }

    public void removeCustomers() {
        while (mCustomers.getRowCount()
                > 0) {
            mCustomers.removeRow(0);
        }
    }

    public void removeAllBills() {

        while (mBillDetails.getRowCount() > 0) {
            mBillDetails.removeRow(0);
        }
    }

    public void refreshCustomers() {
        removeCustomers();
        fillCustomers();
    }

    public void refreshBillDetails() {
        removeAllBills();
        particularBillDetails();
    }

    public void printBill() {
        try {
            String billName = "printBill.html";
            File f = new File(billName);
            f.createNewFile();
            PrintWriter out = new PrintWriter(f);
            String heads2[] = {"BillNo ", "Date", "Tax", "SNo.", "CID", "PID", "MRP"};
            String heads[] = {"Customer ID", "Name", "Email Id", "Contact No", "Address"};
            out.println("<html><body>");
            out.println("<table border='1' width='1200px'>");
            out.println("<tr>");
            out.println("<td align=center colspan='7' > <b> Duplicate Bill</b>");
            out.println("</td>");
            out.println("</tr>");
            out.println("<tr>");
            for (int i = 0; i < heads2.length; i++) {
                out.println("\t<td>" + heads2[i] + "</td>");
            }
            out.println("</tr>");

            for (int i = 0; i < mBillDetails.getRowCount(); i++) {
                out.println("<tr>");
                for (int j = 0; j < heads2.length; j++) {
                    out.println("\t<td>" + mBillDetails.getValueAt(i, j) + "</td>");
                }
                out.println("</tr>");
            }
            out.println("<tr><td colspan='7'>&nbsp;</td></tr>");
            out.println("<tr>");
            out.println("<td align=right colspan='6'>Total</td>");
            out.println("<td>" + tTotal.getText() + "</td>");
            out.println("</tr>");
            out.println("<tr>");
            out.println("<td align=right colspan='6'> Tax</td>");
            out.println("<td>" + tBTax.getText() + "</td>");
            out.println("</tr>");
            out.println("<tr>");
            out.println("<td align=right colspan='6'> Grand Total </td>");
            out.println("<td>" + tGrandTotal.getText() + "</td>");
            out.println("</tr>");

            out.println("</table>");

            out.println("<tr><td>&nbsp;</td></tr>");
            out.println("<tr><td>&nbsp;</td></tr>");

            out.println("<table border='2' width='1200px'>");
            out.println("<tr>");
            for (int i = 0; i < heads.length; i++) {
                out.println("\t<td>" + heads[i] + "</td>");
            }
            out.println("</tr>");

            for (int i = 0; i < mCustomers.getRowCount(); i++) {
                out.println("<tr>");
                for (int j = 0; j < heads.length; j++) {
                    out.println("\t<td>" + mCustomers.getValueAt(i, j) + "</td>");
                }
                out.println("</tr>");
            }

            out.println("<tr><td colspan='7'>&nbsp;</td></tr>");
            out.println("</tr>");
            out.println("</table>");
            out.println("</body></html>");
            out.close();
            Desktop.getDesktop().open(f);

        } catch (Exception ex) {
            // JOptionPane.showMessageDialog(c, ex.toString());
        }

    }

    public void mousePressed(MouseEvent me) {

    }

    public void mouseReleased(MouseEvent me) {
        Object o = me.getSource();
        if (o.equals(tBillDetails)) {
            int row = tBillDetails.getSelectedRow();

            tCID.setText(String.valueOf(mBillDetails.getValueAt(row, 4)));
        }
    }

    public void mouseClicked(MouseEvent me) {

    }

    public void mouseEntered(MouseEvent me) {

    }

    public void mouseExited(MouseEvent me) {

    }

}
