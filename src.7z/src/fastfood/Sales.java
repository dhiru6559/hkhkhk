package fastfood;

import java.awt.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Vector;
import javax.swing.*;
import javax.swing.border.*;
import javax.swing.table.DefaultTableModel;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.io.*;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.util.Calendar;
//import java.util.Formatter;

public class Sales extends JInternalFrame implements MouseListener {

    Container c;
    DefaultTableModel mCustomers, mProducts, mBillDetails;
    JTable tCustomers, tProducts, tBillDetails;
    JTextField tCID, tCName, tBillNo, tTax, tSNo, tPID, tPName, tMRP, tSearch, tBPID, tBCID, tTotal, tBTax, tQuantity, tGrandTotal;
    JFormattedTextField tDate;
    DefaultComboBoxModel<Object> mCategory, mType;
    JComboBox<Object> cbType, cbCategory;
    JButton bNewBill, bAddItem, bNewItem, bDelete, bUpdate, bShow, bSearch, bPrintBill;

    public Sales() {
        c = getContentPane();
        setTitle("Sales");
        //setSize();
        setLayout(null);
        JPanel pCustomer = new JPanel();
        pCustomer.setLayout(null);
        pCustomer.setBackground(Color.lightGray);
        pCustomer.setBorder(BorderFactory.createTitledBorder(BorderFactory.createBevelBorder(1), "Customers"));
        pCustomer.setBounds(50, 60, 500, 300);

        JLabel lCID = new JLabel("CID");
        lCID.setBounds(10, 15, 100, 30);
        pCustomer.add(lCID);

        tCID = new JTextField("");
        tCID.setBounds(40, 15, 100, 30);
        pCustomer.add(tCID);

        JLabel lCName = new JLabel("Name");
        lCName.setBounds(160, 15, 100, 30);
        pCustomer.add(lCName);

        tCName = new JTextField("");
        tCName.setBounds(210, 15, 100, 30);
        pCustomer.add(tCName);

        String heads[] = {"Customer ID", "Name", "Email Id", "Contact No", "Address"};
        mCustomers = new DefaultTableModel(heads, 0);
        tCustomers = new JTable(mCustomers);
        JScrollPane jspCustomer = new JScrollPane(tCustomers);
        jspCustomer.setBounds(20, 50, 400, 200);
        pCustomer.add(jspCustomer);
        fillCustomers();

        c.add(pCustomer);

        JPanel pProducts = new JPanel();
        pProducts.setLayout(null);
        pProducts.setBackground(Color.lightGray);
        pProducts.setBorder(BorderFactory.createTitledBorder(BorderFactory.createBevelBorder(1), "Products"));
        pProducts.setBounds(590, 60, 850, 300);

        JLabel lPID = new JLabel("PID");
        lPID.setBounds(10, 15, 100, 30);
        pProducts.add(lPID);

        tPID = new JTextField("");
        tPID.setBounds(40, 15, 100, 30);
        pProducts.add(tPID);

        JLabel lPName = new JLabel("Name");
        lPName.setBounds(160, 15, 100, 30);
        pProducts.add(lPName);

        tPName = new JTextField("");
        tPName.setBounds(210, 15, 100, 30);
        pProducts.add(tPName);

        JLabel lType = new JLabel("Type");
        lType.setBounds(310, 15, 100, 30);
        pProducts.add(lType);

        mType = new DefaultComboBoxModel<Object>();
        cbType = new JComboBox<Object>(mType);
        cbType.setBounds(350, 15, 100, 30);
        pProducts.add(cbType);
        addType();

        JLabel lCategory = new JLabel("Category");
        lCategory.setBounds(460, 15, 100, 30);
        pProducts.add(lCategory);

        mCategory = new DefaultComboBoxModel<Object>();
        cbCategory = new JComboBox<Object>(mCategory);
        cbCategory.setBounds(530, 15, 100, 30);
        pProducts.add(cbCategory);
        addCategory();

        tSearch = new JTextField("");//yaha sir search likha aayei..
        tSearch.setBounds(640, 15, 120, 30);
        pProducts.add(tSearch);

        bSearch = new JButton("Search");
        bSearch.setBounds(750, 15, 100, 30);
        pProducts.add(bSearch);
        tSearch.addKeyListener(new MyKeyAdopter());

        String heads1[] = {"PID", "Name", "MRP", "Type", "Category"};
        mProducts = new DefaultTableModel(heads1, 0);
        tProducts = new JTable(mProducts);
        JScrollPane jspProducts = new JScrollPane(tProducts);
        jspProducts.setBounds(50, 60, 600, 200);
        pProducts.add(jspProducts);
        fillProducts();

        c.add(pProducts);

        JPanel pChangeItems = new JPanel();
        pChangeItems.setLayout(null);
        pChangeItems.setBackground(Color.lightGray);
        pChangeItems.setBorder(BorderFactory.createTitledBorder(BorderFactory.createBevelBorder(1), "Change Items"));
        pChangeItems.setBounds(100, 400, 150, 300);

        bNewBill = new JButton("New Bill");
        bNewBill.setBounds(20, 15, 100, 30);
        pChangeItems.add(bNewBill);

        bNewItem = new JButton("New Item");
        bNewItem.setBounds(20, 65, 100, 30);
        pChangeItems.add(bNewItem);

        bAddItem = new JButton("Add Item");
        bAddItem.setBounds(20, 115, 100, 30);
        pChangeItems.add(bAddItem);

        bDelete = new JButton("Delete");
        bDelete.setBounds(20, 165, 100, 30);
        pChangeItems.add(bDelete);

        bUpdate = new JButton("Update");
        bUpdate.setBounds(20, 215, 100, 30);
        pChangeItems.add(bUpdate);

        bShow = new JButton("Show");
        bShow.setBounds(20, 265, 100, 30);
        pChangeItems.add(bShow);

        c.add(pChangeItems);

        JPanel pBillDetails = new JPanel();
        pBillDetails.setLayout(null);
        pBillDetails.setBackground(Color.lightGray);
        pBillDetails.setBorder(BorderFactory.createTitledBorder(BorderFactory.createBevelBorder(1), "Bill Details"));
        pBillDetails.setBounds(300, 400, 1400, 300);

        JLabel lBillNo = new JLabel("Bill No");
        lBillNo.setBounds(10, 15, 100, 30);
        pBillDetails.add(lBillNo);

        tBillNo = new JTextField("");
        tBillNo.setBounds(70, 15, 100, 30);
        pBillDetails.add(tBillNo);

        JLabel lDate = new JLabel("Date");
        lDate.setBounds(180, 15, 100, 30);
        pBillDetails.add(lDate);

        try {
            tDate = new JFormattedTextField(new javax.swing.text.MaskFormatter("####-##-##"));
            tDate.setBounds(230, 15, 100, 30);
            pBillDetails.add(tDate);
        } catch (Exception ex) {
        }

        JLabel lTax = new JLabel("Tax");
        lTax.setBounds(340, 15, 100, 30);
        pBillDetails.add(lTax);

        tTax = new JTextField("");
        tTax.setBounds(390, 15, 100, 30);
        pBillDetails.add(tTax);

        JLabel lSNo = new JLabel("S No.");
        lSNo.setBounds(500, 15, 100, 30);
        pBillDetails.add(lSNo);

        tSNo = new JTextField("");
        tSNo.setBounds(550, 15, 100, 30);
        pBillDetails.add(tSNo);

        JLabel lBCID = new JLabel("CID");
        lBCID.setBounds(660, 15, 100, 30);
        pBillDetails.add(lBCID);

        tBCID = new JTextField("");
        tBCID.setBounds(710, 15, 100, 30);
        pBillDetails.add(tBCID);

        JLabel lBPID = new JLabel("PID");
        lBPID.setBounds(820, 15, 100, 30);
        pBillDetails.add(lBPID);

        tBPID = new JTextField("");
        tBPID.setBounds(870, 15, 100, 30);
        pBillDetails.add(tBPID);

        JLabel lMRP = new JLabel("MRP");
        lMRP.setBounds(980, 15, 100, 30);
        pBillDetails.add(lMRP);

        tMRP = new JTextField("");
        tMRP.setBounds(1030, 15, 100, 30);
        pBillDetails.add(tMRP);

        JLabel lQuantity = new JLabel("Quantity");
        lQuantity.setBounds(1150, 15, 100, 30);
        pBillDetails.add(lQuantity);

        tQuantity = new JTextField("");
        tQuantity.setBounds(1220, 15, 100, 30);
        pBillDetails.add(tQuantity);

        String heads2[] = {"BillNo ", "Date", "Tax", "SNo.", "CID", "PID", "MRP", "Quantity", "SubTotal"};
        mBillDetails = new DefaultTableModel(heads2, 0);
        tBillDetails = new JTable(mBillDetails);
        JScrollPane jspBillDetails = new JScrollPane(tBillDetails);
        jspBillDetails.setBounds(40, 70, 900, 100);
        pBillDetails.add(jspBillDetails);

        bPrintBill = new JButton("Print Bill");
        bPrintBill.setBounds(40, 170, 100, 30);
        pBillDetails.add(bPrintBill);

        JLabel lBTax = new JLabel("TAX");
        lBTax.setBounds(1030, 170, 100, 30);
        pBillDetails.add(lBTax);

        tBTax = new JTextField("");
        tBTax.setBounds(1080, 170, 100, 30);
        pBillDetails.add(tBTax);

        JLabel lTotal = new JLabel("Total");
        lTotal.setBounds(1030, 210, 100, 30);
        pBillDetails.add(lTotal);

        tTotal = new JTextField("");
        tTotal.setBounds(1080, 210, 100, 30);
        pBillDetails.add(tTotal);

        JLabel lGrandTotal = new JLabel(" Grand Total");
        lGrandTotal.setBounds(980, 255, 100, 30);
        pBillDetails.add(lGrandTotal);

        tGrandTotal = new JTextField("");
        tGrandTotal.setBounds(1080, 255, 100, 30);
        pBillDetails.add(tGrandTotal);

        c.add(pBillDetails);
        bPrintBill.addActionListener(e -> printBill());
        //bSearch.addActionListener(e -> Search());
        bNewBill.addActionListener(e -> newBill());
        bNewItem.addActionListener(e -> newItem());
        bAddItem.addActionListener(e -> {
            addItems();
            totalBill();
            grandtotal();
            particularBillDetails();
        });
        bUpdate.addActionListener(e -> update());
        bDelete.addActionListener(e -> delete());
        bShow.addActionListener(e -> {
            removeAllBills();
            showBills();
            totalBill();
            grandtotal();
        });
        tProducts.addMouseListener(this);
        tCustomers.addMouseListener(this);
        tBillDetails.addMouseListener(this);
        setVisible(true);
        setClosable(true);
    }

    public void fillCustomers() {
        try {
            Connection con = Data.getConnection();
            PreparedStatement ps = con.prepareStatement("Select * from Customers");
            ResultSet rs = ps.executeQuery();
            Vector<Object> v;
            while (rs.next()) {
                v = new Vector<Object>();
                v.add(rs.getInt(1));
                v.add(rs.getString(2));
                v.add(rs.getString(3));
                v.add(rs.getString(4));
                v.add(rs.getString(5));
                mCustomers.addRow(v);

            }
            con.close();

        } catch (Exception ex) {
            JOptionPane.showMessageDialog(c, ex.toString());
        }
    }

    public void fillProducts(String sql) {
        try {
            Connection con = Data.getConnection();
            PreparedStatement ps = con.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            Vector<Object> v;
            while (rs.next()) {
                v = new Vector<Object>();
                v.add(rs.getInt(1));
                v.add(rs.getString(2));
                v.add(rs.getInt(3));
                v.add(rs.getString(4));
                v.add(rs.getString(5));
                mProducts.addRow(v);
            }
            con.close();
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(c, ex.toString());
        }
    }

    public void fillProducts() {
        try {
            Connection con = Data.getConnection();
            PreparedStatement ps = con.prepareStatement("Select * from Products");
            ResultSet rs = ps.executeQuery();
            Vector<Object> v;
            while (rs.next()) {
                v = new Vector<Object>();
                v.add(rs.getInt(1));
                v.add(rs.getString(2));
                v.add(rs.getInt(3));
                v.add(rs.getString(4));
                v.add(rs.getString(5));
                mProducts.addRow(v);
            }
            con.close();
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(c, ex.toString());
        }
    }

    void addType() {
        mType.addElement("None");
        mType.addElement("Veg");
        mType.addElement("Non-Veg");

    }

    void addCategory() {
        mCategory.addElement("None");
        mCategory.addElement("Chinese");
        mCategory.addElement("South Indian");
        mCategory.addElement("Italian");
    }

    public void printBill() {
        try {
            String billName = "printBill.html";
            File f = new File(billName);
            f.createNewFile();
            PrintWriter out = new PrintWriter(f);
            String heads2[] = {"S.No", "Products", "Quantity", "Price", "Amount"};
            out.println("<html><body>");
            out.println("<table border='1' width='1200px'>");
            out.println("<tr>");
            out.println("<td align=center width='100px' height='150px'>Logo");
            out.println("<img src='images/1492702258_fries.png' alt='Mountain View' style='width:304px;height:228px;'>");
            out.println("</td>");
            out.println("<td align=center width='550px'height='150px'><b>Name &nbsp; </b>");
            out.println("</td>");
            //out.println("<td>" + getName() + "</td>");
            out.println("</td>");
            out.println("<td align=center width='550px' height='150px'><b>Address &nbsp;  </b>" + getAddress());
            // out.println("<td>" + getAddress() + "</td>");
            out.println("</td>");
            out.println("</tr>");

            out.println("<tr height='100px'>");
            out.println("<td width='650px' colspan='2'> To: " + getName());
            out.println("</td>");
            out.println("<td width='550px'<b> Bill No " + tBillNo.getText() + " <br><br><br> Date " + getDate() + "</td>");
            //out.println("<td  <br><br><br> Date>" + getDate() + "</td>");
            // out.println("<td>" + getDate() + "</td>");
            //out.println("<td>" + tBillNo.getText() + "</td>");
            out.println("</tr>");

            out.println("</table>");
            out.println("<table border='1' width='1200px'>");
            out.println("<tr>");
            int sum = 0;
            for (int i = 0; i < heads2.length; i++) {
                out.println("\t<td>" + heads2[i] + "</td>");
            }
            try {
                Connection con = Data.getConnection();

                PreparedStatement ps = con.prepareStatement("Select Name,Quantity,Price,(Quantity*Price) from Products inner join Bill_Details on Products.PID=Bill_Details.PID where Bill_Details.BillNo=? ");
                ps.setInt(1, Integer.parseInt(tBillNo.getText()));
                ResultSet rs = ps.executeQuery();
                int i = 1;
                while (rs.next()) {
                    out.println("<tr>");
                    out.println("<td>" + i + "</td>");
                    for (int j = 0; j < 4; j++) {
                        if (j == 3) {
                            int revenue = rs.getInt(j + 1);
                            sum += revenue;
                            out.println("<td>" + revenue + "</td>");
                        } else {
                            out.println("<td>" + rs.getString(j + 1) + "</td>");
                        }

                    }
                    out.println("</tr>");
                    ++i;
                }
                // out.println(sum);
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(c, ex.toString());
            }
            out.println("<tr>");
            out.println("<td align='right' colspan='4'> Total ");
            out.println("<td>" + sum + "</td>");
            out.println("</tr>");

            int tax = sum * 24 / 100;
            out.println("<tr>");
            out.println("<td align='right' colspan='4'> Tax ");
            out.println("<td>" + tax + "</td>");
            out.println("</tr>");

            int grandtotal = sum + tax;
            out.println("<tr>");
            out.println("<td align='right' colspan='4'> GrandTotal ");
            out.println("<td>" + grandtotal + "</td>");
            out.println("</tr>");

            /*  for (int i = 0; i < mBillDetails.getRowCount(); i++) {
                out.println("<tr>");
                for (int j = 0; j < heads2.length; j++) {
                    out.println("\t<td>" + mBillDetails.getValueAt(i, j) + "</td>");
                }
                out.println("</tr>");
            }
             */
            out.println("</tr>");

            out.println("</table>");
            
       /*     <script  language ='javascript' type ='text/javascript'>
              if (window.print) {
                self.print();
            }
            setTimeout('window.close()',1000);
            
               </script >
          */             
         
        
        out.println("</body></html>");
        out.close();
        Desktop.getDesktop().open(f);

    }
    catch (Exception ex

    
        ) {
            JOptionPane.showMessageDialog(c, ex.toString());
    }
}

/*public void printBill() {
        try {
            String billName = "printBill.html";
            File f = new File(billName);
            f.createNewFile();
            PrintWriter out = new PrintWriter(f);

            String heads2[] = {"BillNo ", "Date", "Tax", "SNo.", "CID", "PID", "MRP"};
            out.println("<html><body>");
            out.println("<table border='1' width='1200px'>");
            out.println("<tr>");
            out.println("<td align=center colspan='7' > <b>  Bill Details </b>");
            out.println("</td>");
            out.println("</tr>");
            out.println("<tr>");
            for (int i = 0; i < heads2.length; i++) {
                out.println("\t<td>" + heads2[i] + "</td>");
            }
            out.println("</tr>");

            for (int i = 0; i < mBillDetails.getRowCount(); i++) {
                out.println("<tr>");
                for (int j = 0; j < heads2.length; j++) {
                    out.println("\t<td>" + mBillDetails.getValueAt(i, j) + "</td>");
                }
                out.println("</tr>");
            }
            out.println("<tr><td colspan='7'>&nbsp;</td></tr>");
            out.println("<tr>");
            out.println("<td align=right colspan='6'>Total</td>");
            out.println("<td>" + tTotal.getText() + "</td>");
            out.println("</tr>");
            out.println("<tr>");
            out.println("<td align=right colspan='6'> Tax</td>");
            out.println("<td>" + tBTax.getText() + "</td>");
            out.println("</tr>");
            out.println("<tr>");
            out.println("<td align=right colspan='6'> Grand Total </td>");
            out.println("<td>" + tGrandTotal.getText() + "</td>");
            out.println("</tr>");
            out.println("</table>");
            out.println("</body></html>");
            out.close();
            Desktop.getDesktop().open(f);

        } catch (Exception ex) {
            JOptionPane.showMessageDialog(c, ex.toString());
        }
    }*/
public void mousePressed(MouseEvent me) {

    }

    public void mouseReleased(MouseEvent me) {
        Object o = me.getSource();
        if (o.equals(tCustomers)) {
            int row = tCustomers.getSelectedRow();
            tCID.setText(String.valueOf(mCustomers.getValueAt(row, 0)));
            tCName.setText(String.valueOf(mCustomers.getValueAt(row, 1)));
            tBCID.setText(String.valueOf(mCustomers.getValueAt(row, 0)));
        }
        if (o.equals(tProducts)) {
            int row = tProducts.getSelectedRow();
            tPID.setText(String.valueOf(mProducts.getValueAt(row, 0)));
            tPName.setText(String.valueOf(mProducts.getValueAt(row, 1)));
            tMRP.setText(String.valueOf(mProducts.getValueAt(row, 2)));
            cbType.setSelectedItem(tProducts.getModel().getValueAt(row, 3));
            cbCategory.setSelectedItem(tProducts.getModel().getValueAt(row, 4));
            tBPID.setText(String.valueOf(mProducts.getValueAt(row, 0)));
            //tBillNo.setText(String.valueOf(mProducts.getValueAt(row, 0)));
        }
        if (o.equals(tBillDetails)) {
            int row = tBillDetails.getSelectedRow();
            tBillNo.setText(String.valueOf(mBillDetails.getValueAt(row, 0)));
            tDate.setText(String.valueOf(mBillDetails.getValueAt(row, 1)));
            tTax.setText(String.valueOf(mBillDetails.getValueAt(row, 2)));
            tSNo.setText(String.valueOf(mBillDetails.getValueAt(row, 3)));
            tBCID.setText(String.valueOf(mBillDetails.getValueAt(row, 4)));
            tBPID.setText(String.valueOf(mBillDetails.getValueAt(row, 5)));
            tMRP.setText(String.valueOf(mBillDetails.getValueAt(row, 6)));
            tQuantity.setText(String.valueOf(mBillDetails.getValueAt(row, 7)));
        }
    }

    public void mouseClicked(MouseEvent me) {

    }

    public void mouseEntered(MouseEvent me) {

    }

    public void mouseExited(MouseEvent me) {

    }

    public void removeAllProducts() {
        int n = mProducts.getRowCount();
        for (int i = n - 1; i >= 0; i--) {
            mProducts.removeRow(i);
        }
    }

    public void removeAllCustomers() {
        //int n = mCustomers.getRowCount();
        while (mCustomers.getRowCount() > 0) {
            mCustomers.removeRow(0);
        }
    }

    public void removeAllBills() {
        //int n = mBillDetails.getRowCount();
        while (mBillDetails.getRowCount() > 0) {
            mBillDetails.removeRow(0);
        }
    }

    public void refreshProducts() {
        removeAllProducts();
        fillProducts();
    }

    public void refreshCustomers() {
        removeAllCustomers();
        fillCustomers();
    }

    public void refreshBillDetails() {
        removeAllBills();
        particularBillDetails();
    

}

    class MyKeyAdopter extends KeyAdapter {

    public void keyReleased(KeyEvent ke) {

        removeAllProducts();
        fillProducts("Select * from Products where Name like '" + tSearch.getText() + "%'");
    }

}

public void newBill() {
        Calendar ca = Calendar.getInstance();
        try {

            Connection con = Data.getConnection();
            PreparedStatement ps = con.prepareStatement("Select Max(BillNo) from Bill_Info");
            ResultSet rs = ps.executeQuery();
            int nextId = 0;
            if (rs.next()) {
                nextId = rs.getInt(1);
            }
            ++nextId;

            tDate.setText(String.format("%tY-%tm-%td", ca, ca, ca));
            tBillNo.setText(String.valueOf(nextId));
            con.close();
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(c, ex.toString());
        }
        tBCID.setText("");
        tBPID.setText("");
        tSNo.setText("");
        tTax.setText("");
        tMRP.setText("");
        tBTax.setText("");
        tTotal.setText("");
        removeAllBills();
        //particularBillDetails();
    }

    public void particularBillDetails() {
        removeAllBills();

        try {
            Connection con = Data.getConnection();
            PreparedStatement ps = con.prepareStatement("Select Bill_Info.BillNo,Bill_Info.BillDate,Bill_Info.Tax,Bill_Details.SNo,Bill_Details.CID,Bill_Details.PID,Bill_Details.Price,Bill_Details.Quantity,Bill_Details.Price*Bill_Details.Quantity as subtotal from Bill_Info inner join Bill_Details on Bill_Info.BillNo=Bill_Details.BillNo where Bill_Info.BillNo=?");
            ps.setInt(1, Integer.parseInt(tBillNo.getText()));
            ResultSet rs = ps.executeQuery();
            Vector<Object> v;
            while (rs.next()) {
                v = new Vector<Object>();
                v.add(rs.getInt(1));
                v.add(rs.getString(2));
                v.add(rs.getInt(3));
                v.add(rs.getInt(4));
                v.add(rs.getInt(5));
                v.add(rs.getInt(6));
                v.add(rs.getInt(7));
                v.add(rs.getInt(8));
                v.add(rs.getInt(9));

                mBillDetails.addRow(v);
            }
            con.close();
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(c, ex.toString());
        }

    }

    public void newItem() {
        totalBill();
        try {

            Connection con = Data.getConnection();
            PreparedStatement ps = con.prepareStatement("Select Max(SNo) from Bill_Details");
            ResultSet rs = ps.executeQuery();
            int nextId = 0;
            if (rs.next()) {
                nextId = rs.getInt(1);
            }
            ++nextId;

            tSNo.setText(String.valueOf(nextId));
            con.close();
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(c, ex.toString());
        }
        tBPID.setText("");
        tMRP.setText("");

    }

    public void saveBillInfo() {
        try {
            Connection con = Data.getConnection();
            PreparedStatement ps = con.prepareStatement("insert into Bill_Info values(?,?,?)");
            ps.setInt(1, Integer.parseInt(tBillNo.getText()));
            ps.setString(2, tDate.getText());
            ps.setDouble(3, Double.parseDouble(tTax.getText()));
            int count = ps.executeUpdate();
            if (count > 0) {
                JOptionPane.showMessageDialog(c, "1st record");
            }
            con.close();
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(c, ex.toString());
        }

    }

    public void saveBillDetails() {
        try {
            Connection con = Data.getConnection();
            PreparedStatement ps = con.prepareStatement("insert into Bill_Details values(?,?,?,?,?,?)");
            ps.setInt(1, Integer.parseInt(tSNo.getText()));
            ps.setInt(2, Integer.parseInt(tBillNo.getText()));
            ps.setInt(3, Integer.parseInt(tBCID.getText()));
            ps.setInt(4, Integer.parseInt(tBPID.getText()));
            ps.setInt(5, Integer.parseInt(tQuantity.getText()));
            ps.setInt(6, Integer.parseInt(tMRP.getText()));

            int count = ps.executeUpdate();
            if (count > 0) {
                JOptionPane.showMessageDialog(c, "2nd Record Saved Successfully");
            }
            con.close();

        } catch (Exception ex) {
            JOptionPane.showMessageDialog(c, ex.toString());
        }
    }

    public boolean isBillNoExist(String billNo) {
        try {
            Connection con = Data.getConnection();
            PreparedStatement ps = con.prepareStatement("Select BillNo from Bill_Info where BillNo=?");
            ps.setInt(1, Integer.parseInt(billNo));
            ResultSet rs = ps.executeQuery();
            boolean flag = rs.next();
            con.close();
            return flag;

        } catch (Exception ex) {
            // JOptionPane.showMessageDialog(c, ex.toString());
            return false;
        }

    }

    public void addItems() {
        try {
            boolean b = isBillNoExist((tBillNo.getText()));
            if (!b) {
                saveBillInfo();
                System.out.println("Bill Info saved");
                //saveBillDetails();
            }

            //if (b) {
            // saveBillInfo();
            saveBillDetails();
            //}
        } catch (Exception ex) {

        }

    }

    public void delete() {
        try {
            Connection con = Data.getConnection();
            PreparedStatement ps = con.prepareStatement("delete from Bill_Details where SNo=?");
            ps.setInt(1, Integer.parseInt(tPID.getText()));
            int count = ps.executeUpdate();
            if (count > 0) {
                JOptionPane.showMessageDialog(c, "Deleted");
            }
            con.close();
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(c, ex.toString());
        }

        refreshBillDetails();

    }

    public void showBills() {
        //totalBill();
        //removeAllBills();
        if (tBillNo.getText().isEmpty()) {
            allBillDetails();
            return;
        }
        try {

            boolean b = isBillNoExist((tBillNo.getText()));
            if (!b) {
                allBillDetails();
            }
            if (b) {
                particularBillDetails();
            }
        } catch (Exception ex) {

        }

    }

    public void allBillDetails() {
        try {

            Connection con = Data.getConnection();
            PreparedStatement ps = con.prepareStatement("Select Bill_Info.BillNo,Bill_Info.BillDate,Bill_Info.Tax,Bill_Details.SNo,Bill_Details.CID,Bill_Details.PID,Bill_Details.Price,Bill_Details.Quantity,Bill_Details.Price*Bill_Details.Quantity as subtotal from Bill_Info inner join Bill_Details on Bill_Info.BillNo=Bill_Details.BillNo");
            /*"Select Bill_Info.BillNo,Bill_Info.BillDate,Bill_Info.Tax,Bill_Details.SNo,Bill_Details.CID,Bill_Details.PID,Bill_Details.Price,Bill_Details.Quantity,Bill_Details.Price*Bill_Details.Quantity as subtotal from Bill_Info inner JOIN Bill_Details ON Bill_Info.BillNo=Bill_Details.BillNo"*/

            ResultSet rs = ps.executeQuery();

            Vector<Object> v;
            while (rs.next()) {
                v = new Vector<Object>();
                v.add(rs.getInt(1));
                v.add(rs.getString(2));
                v.add(rs.getInt(3));
                v.add(rs.getInt(4));
                v.add(rs.getInt(5));
                v.add(rs.getInt(6));
                v.add(rs.getInt(7));
                v.add(rs.getInt(8));
                v.add(rs.getInt(9));

                mBillDetails.addRow(v);
            }
            con.close();
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(c, ex.toString());
        }

    }

    public void update() {

        try {
            Connection con = Data.getConnection();
            PreparedStatement ps = con.prepareStatement("update Bill_Details set BillNo=?, CID=?,PID=?,Quantity=?,Price=? where SNo=?");
            ps.setInt(1, Integer.parseInt(tBillNo.getText()));
            ps.setInt(2, Integer.parseInt(tBCID.getText()));
            ps.setInt(3, Integer.parseInt(tBPID.getText()));
            ps.setInt(4, Integer.parseInt(tQuantity.getText()));
            ps.setInt(5, Integer.parseInt(tMRP.getText()));
            ps.setInt(6, Integer.parseInt(tSNo.getText()));
            int count = ps.executeUpdate();
            if (count > 0) {
                JOptionPane.showMessageDialog(c, "Updated Successfully!");
            }
            con.close();
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(c, ex.toString());
        }
        refreshBillDetails();

    }

    public void totalBill() {
        try {

            int sum = 0, tax = 0;

            for (int i = 0; i < mBillDetails.getRowCount(); ++i) {
                String str = (String.valueOf(mBillDetails.getValueAt(i, 8)));
                sum = sum + Integer.parseInt(str);
                tax = sum * 24 / 100;
            }
            tTotal.setText(String.valueOf(sum));
            tBTax.setText(String.valueOf(tax));
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(c, ex.toString());

        }
    }

    public void grandtotal() {
        int grandtotal = Integer.parseInt(tTotal.getText()) + Integer.parseInt(tBTax.getText());
        tGrandTotal.setText(String.valueOf(grandtotal));
    }

    public String getName() {
        try {
            Connection con = Data.getConnection();
            PreparedStatement ps = con.prepareStatement("select name from Customers where CID in(select CID from Bill_Details where BillNo=?)");
            ps.setInt(1, Integer.parseInt(tBillNo.getText()));
            ResultSet rs = ps.executeQuery();
            //JOptionPane.showMessageDialog(c, tBillNo.getText());
            String name = null;
            if (rs.next()) {
                name = rs.getString(1);
            }
            con.close();
            return name;

        } catch (Exception ex) {
            JOptionPane.showMessageDialog(c, ex.toString());

        }
        return null;

    }

    public String getAddress() {
        try {
            Connection con = Data.getConnection();
            PreparedStatement ps = con.prepareStatement("select address from Customers where CID in(select CID from Bill_Details where BillNo=?)");
            ps.setInt(1, Integer.parseInt(tBillNo.getText()));
            ResultSet rs = ps.executeQuery();
            String address = null;
            if (rs.next()) {
                address = rs.getString(1);
            }
            con.close();
            return address;

        } catch (Exception ex) {
            JOptionPane.showMessageDialog(c, ex.toString());

        }
        return null;

    }

    public String getDate() {
        try {
            Connection con = Data.getConnection();
            PreparedStatement ps = con.prepareStatement("select BillDate from Bill_Info inner join Bill_Details on Bill_Info.BillNo=Bill_Details.BillNo where Bill_Details.BillNo=?");
            ps.setInt(1, Integer.parseInt(tBillNo.getText()));
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                java.util.Date d;
                d = rs.getDate(1);
                String dateOfBill = String.format("%td-%tm-%tY", d, d, d);
                con.close();

                return dateOfBill;
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(c, ex.toString());

        }
        return null;

    }

}
