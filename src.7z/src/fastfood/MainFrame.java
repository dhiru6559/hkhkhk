package fastfood;

import java.awt.*;
import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.Image;

/*
  Image img = icon.getImage() ;  
   Image newimg = img.getScaledInstance( NEW_WIDTH, NEW_HEIGHT,  java.awt.Image.SCALE_SMOOTH ) ;  
   icon = new ImageIcon( newimg );
 */
public class MainFrame extends JFrame implements ActionListener {

    Container c;
    JToolBar tBar;
    JInternalFrame iFrame;
    JButton bSales, bCustomers, bProducts, bReport, bExit;

    public MainFrame() {
        c = getContentPane();
        setSize(Toolkit.getDefaultToolkit().getScreenSize());
        setLayout(new BorderLayout());
        setTitle("Welcome to Eat and Street");
        //setLayout(null);
        c.setBackground(Color.lightGray);
        fillTop();
        setVisible(true);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

    }

    void fillTop() {
        tBar = new JToolBar("Dheeraj");
        tBar.setLayout(new GridLayout(1,100,20, 10));
        ImageIcon icon = new ImageIcon("images/sales.png");
        Image img = icon.getImage();
        Image newimg = img.getScaledInstance(400, 200, java.awt.Image.SCALE_SMOOTH);
        icon = new ImageIcon(newimg);

        bSales = new JButton(new ImageIcon(icon.getImage()));
       // bSales.setBounds(300, 5, 200, 200);
        c.add(bSales);

        icon = new ImageIcon("images/customers.jpeg");
        Image img1 = icon.getImage();
        newimg = img1.getScaledInstance(400, 200, java.awt.Image.SCALE_SMOOTH);
        icon = new ImageIcon(newimg);
        bCustomers = new JButton(new ImageIcon(icon.getImage()));
        // bCustomers = new JButton(new ImageIcon("images/customers.jpeg"));
        //bCustomers.setBounds(550, 5, 200, 200);
        //c.add(bCustomers);

        icon = new ImageIcon("images/products.jpeg");
        Image img2 = icon.getImage();
        newimg = img2.getScaledInstance(350, 200, java.awt.Image.SCALE_SMOOTH);
        icon = new ImageIcon(newimg);

        bProducts = new JButton(new ImageIcon(icon.getImage()));
        //bProducts.setBounds(800, 5, 200, 200);
        //c.add(bProducts);

        icon = new ImageIcon("images/report.png");
        Image img3 = icon.getImage();
        newimg = img3.getScaledInstance(200, 200, java.awt.Image.SCALE_SMOOTH);
        icon = new ImageIcon(newimg);

        bReport = new JButton(new ImageIcon(icon.getImage()));
        //bReport.setBounds(1050, 5, 200, 200);
        //c.add(bReport);

        icon = new ImageIcon("images/exit.png");
        Image img4 = icon.getImage();
        newimg = img4.getScaledInstance(200, 200, java.awt.Image.SCALE_SMOOTH);
        icon = new ImageIcon(newimg);

        bExit = new JButton(new ImageIcon(icon.getImage()));
        //bExit.setBounds(1300, 5, 200, 200);
        //c.add(bExit);

        bSales.setToolTipText("Sales");
        bCustomers.setToolTipText("Customers");
        bProducts.setToolTipText("Products");
        bReport.setToolTipText("Report");
        bExit.setToolTipText("Exit");
        tBar.add(bSales);
        tBar.add(bCustomers);
        tBar.add(bProducts);
        tBar.add(bReport);
        tBar.add(bExit);
         
        bSales.addActionListener(this);
        bCustomers.addActionListener(this);
        bProducts.addActionListener(this);
        bReport.addActionListener(this);
        bExit.addActionListener(e -> System.exit(0));
        c.add(tBar, BorderLayout.NORTH);
    }

    public void actionPerformed(ActionEvent ae) {
        Object o = ae.getSource();
        try {
            iFrame.setClosed(true);
        } catch (Exception ex) {

        }
        if (o.equals(bSales)) {
            iFrame = new Sales();
            c.add(iFrame);
        } else if (o.equals(bCustomers)) {
            iFrame = new Customers();
            c.add(iFrame);

        } else if (o.equals(bProducts)) {
            iFrame = new Products();
            c.add(iFrame);

        } else if (o.equals(bReport)) {
            iFrame = new BillDetails();
            c.add(iFrame);

        }

    }

}
