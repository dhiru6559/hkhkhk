package fastfood;

public class Fastfood {

    public static void main(String[] args) {
     /*  try{
        Mail.sendMail("gouravkhurana251@gmail.com","hello","mail programm");
    	System.out.println("Hello World!");
        }
        catch(Exception ex){
            
        }*/
        new MainFrame();
    }

}
