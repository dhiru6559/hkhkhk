package fastfood;

import java.awt.*;
import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.sql.DriverManager;
import javax.swing.table.DefaultTableModel;
import java.util.Vector;
import java.sql.*;

public class Customers extends JInternalFrame implements ActionListener, MouseListener,KeyListener {

    Container c;
    JLabel lCID, lName, lEmailId, lContactNo, lAddress;
    JTextField tCID, tName, tEmailId, tContactNo;
    JButton bAdd, bDelete, bNew, bUpdate, bExit;
    JTextArea tAddress;
    DefaultTableModel mCustomers;
    JTable tCustomers;

    Customers() {
        c = getContentPane();
        setTitle("Customers");
        setLayout(null);

        lCID = new JLabel("Id");
        lCID.setBounds(30, 20, 100, 30);
        c.add(lCID);

        tCID = new JTextField("");
        tCID.setBounds(150, 20, 100, 30);
        c.add(tCID);

        lName = new JLabel("Name");
        lName.setBounds(30, 70, 100, 30);
        c.add(lName);

        tName = new JTextField("");
        tName.setBounds(150, 70, 100, 30);
        c.add(tName);

        lEmailId = new JLabel("Email Id");
        lEmailId.setBounds(30, 120, 100, 30);
        c.add(lEmailId);

        tEmailId = new JTextField("");
        tEmailId.setBounds(150, 120, 100, 30);
        c.add(tEmailId);

        lContactNo = new JLabel("Contact No.");
        lContactNo.setBounds(30, 170, 100, 30);
        c.add(lContactNo);

        tContactNo = new JTextField("");
        tContactNo.setBounds(150, 170, 100, 30);
        c.add(tContactNo);

        lAddress = new JLabel("Address");
        lAddress.setBounds(30, 220, 100, 30);
        c.add(lAddress);

        tAddress = new JTextArea();
        tAddress.setLineWrap(true);
        JScrollPane jspAddress = new JScrollPane(tAddress);
        jspAddress.setBounds(150, 220, 100, 100);
        c.add(jspAddress);

        ImageIcon addImage=new ImageIcon("images/add.png");
        bAdd = new JButton("Add",addImage);
        bAdd.setBounds(30, 330, 100, 30);
        c.add(bAdd);
        bAdd.setBackground(Color.LIGHT_GRAY);
        
        ImageIcon deleteImage=new ImageIcon("images/delete.png");
        bDelete = new JButton("Delete",deleteImage);
        bDelete.setBounds(150, 330, 120, 30);
        c.add(bDelete);
        bDelete.setBackground(Color.LIGHT_GRAY);

        ImageIcon newImage=new ImageIcon("images/new.png");
        bNew = new JButton("New",newImage);
        bNew.setBounds(30, 380, 100, 30);
        c.add(bNew);
        bNew.setBackground(Color.LIGHT_GRAY);
        
        ImageIcon updateImage=new ImageIcon("images/update.png");
        bUpdate = new JButton("Update",updateImage);
        bUpdate.setBounds(150, 380, 120, 30);
        c.add(bUpdate);
        bUpdate.setBackground(Color.LIGHT_GRAY);
        
        ImageIcon exitImage=new ImageIcon("images/exit1.png");
        bExit = new JButton("Exit",exitImage);
        bExit.setBounds(30, 430, 100, 30);
        c.add(bExit);
        bExit.setBackground(Color.LIGHT_GRAY);

        String heads[] = {"Customer ID", "Name", "Email Id", "Contact No", "Address"};
        mCustomers = new DefaultTableModel(heads, 0);
        tCustomers = new JTable(mCustomers);
        JScrollPane jspCustomer = new JScrollPane(tCustomers);
        jspCustomer.setBounds(500, 30, 800, 300);
        c.add(jspCustomer);
        fillCustomer();

        bAdd.addActionListener(e -> addCustomer());
        bNew.addActionListener(e -> New());
        bUpdate.addActionListener(e -> update());
        bDelete.addActionListener(e -> delete());
        bExit.addActionListener(e -> System.exit(0));
        tCID.addKeyListener(this);
        tContactNo.addKeyListener(this);
        tCustomers.addMouseListener(this);
        setVisible(true);
        // setDefaultCloseOperation(3);
        setClosable(true);
    }

    void fillCustomer() {
        try {
            Connection con = Data.getConnection();
            PreparedStatement ps = con.prepareStatement("Select * from Customers");
            ResultSet rs = ps.executeQuery();
            Vector<Object> v;
            while (rs.next()) {
                v = new Vector<Object>();
                v.add(rs.getInt(1));
                v.add(rs.getString(2));
                v.add(rs.getString(3));
                v.add(rs.getString(4));
                v.add(rs.getString(5));
                mCustomers.addRow(v);

            }
            con.close();

        } catch (Exception ex) {
            JOptionPane.showMessageDialog(c, ex.toString());
        }
    }

    void addCustomer() {
        try {
            Connection con = Data.getConnection();
            PreparedStatement ps = con.prepareStatement("insert into Customers values(?,?,?,?,?)");
            ps.setInt(1, Integer.parseInt(tCID.getText()));
            ps.setString(2, tName.getText());
            ps.setString(3, tEmailId.getText());
            ps.setString(4, tContactNo.getText());
            ps.setString(5, tAddress.getText());

            int count = ps.executeUpdate();
            if (count > 0) {
                JOptionPane.showMessageDialog(c, "Record Saved Successfully");
            }
            con.close();
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(c, ex.toString());
        }
        refreshMember();
        tName.setText("");
        tEmailId.setText("");
        tContactNo.setText("");
        tAddress.setText("");
        tName.requestFocus();

    }

    void delete() {
        try {

            Connection con = Data.getConnection();
            PreparedStatement ps = con.prepareStatement("delete from Customers where CID=?");
            ps.setInt(1, Integer.parseInt(tCID.getText()));
            int count = ps.executeUpdate();
            if (count > 0) {
                JOptionPane.showMessageDialog(c, "Record Deleted Successfully");
            }
            con.close();
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(c, ex.toString());
        }
        refreshMember();
        tCID.setText("");
        tName.setText("");
        tEmailId.setText("");
        tContactNo.setText("");
        tAddress.setText("");
        tName.requestFocus();
    }

    void New() {
        try {

            Connection con = Data.getConnection();
            PreparedStatement ps = con.prepareStatement("Select Max(CID) from Customers");
            ResultSet rs = ps.executeQuery();
            int nextId = 0;
            if (rs.next()) {
                nextId = rs.getInt(1);
            }
            ++nextId;

            tCID.setText(String.valueOf(nextId));
            con.close();
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(c, ex.toString());
        }
        tName.setText("");
        tEmailId.setText("");
        tContactNo.setText("");
        tAddress.setText("");
        tName.requestFocus();

    }

    void update() {
        try {
            Connection con = Data.getConnection();
            PreparedStatement ps = con.prepareStatement("update Customers set Name=?, EmailId=?,ContactNo=?,Address=? where CID=?");

            ps.setString(1, tName.getText());
            ps.setString(2, tEmailId.getText());
            ps.setString(3, tContactNo.getText());
            ps.setString(4, tAddress.getText());
            ps.setInt(5, Integer.parseInt(tCID.getText()));
            int count = ps.executeUpdate();
            if (count > 0) {
                JOptionPane.showMessageDialog(c, "Updated Successfully!");
            }
            con.close();
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(c, ex.toString());
        }
        refreshMember();

    }

    void removeAllMember() {
        while (mCustomers.getRowCount() > 0) {
            mCustomers.removeRow(0);
        }

    }

    void refreshMember() {
        removeAllMember();
        fillCustomer();
    }

    public void actionPerformed(ActionEvent ae) {

    }

    public void mousePressed(MouseEvent me) {

    }

    public void mouseReleased(MouseEvent me) {
        Object o = me.getSource();
        if (o.equals(tCustomers)) {
            int row = tCustomers.getSelectedRow();
            tCID.setText(String.valueOf(mCustomers.getValueAt(row, 0)));
            tName.setText(String.valueOf(mCustomers.getValueAt(row, 1)));
            tEmailId.setText(String.valueOf(mCustomers.getValueAt(row, 2)));
            tContactNo.setText(String.valueOf(mCustomers.getValueAt(row, 3)));
            tAddress.setText(String.valueOf(mCustomers.getValueAt(row, 4)));

        }
    }

    public void mouseClicked(MouseEvent me) {

    }

    public void mouseEntered(MouseEvent me) {

    }

    public void mouseExited(MouseEvent me) {

    }
    
    public void keyTyped(KeyEvent ke){
        Object o=ke.getSource();
        if(o.equals(tContactNo)|| o.equals(tCID)){
            char kCode=ke.getKeyChar();
            setTitle(kCode+"");
            if(!(kCode>=48 && kCode<=57))
                ke.consume();
        }
    }
    
    public void keyPressed(KeyEvent ke){
        
    }
    public void keyReleased(KeyEvent ke){
        
    }
    public boolean isEmailValid(String s){
        char[] special={'!','#','$','%','^','&','*','(',')','<','>','?','/'};
        int indexOfAtRate=s.indexOf('@');
        int indexOfDot=s.lastIndexOf('.');
        int count=0;
        System.out.println(indexOfAtRate+" "+indexOfDot);
        if(indexOfAtRate>indexOfDot)
            return false;
        if(Character.isDigit(s.charAt(0)))
            return false;
        if(s.endsWith("."))
            return false;
        if(s.substring(indexOfDot).length()<3)
        return false;
        for(int i=0;i<s.length();i++)
        {
            if(s.charAt(i)=='@')
                count++;
        }
        if(count!=1)
            return false;return true;
            
    }
    

}
