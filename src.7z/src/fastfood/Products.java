package fastfood;

import java.awt.*;
import javax.swing.*;
import java.util.Vector;
import javax.swing.table.DefaultTableModel;
import java.sql.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseListener;
import java.awt.event.MouseEvent;

public class Products extends JInternalFrame implements MouseListener {

    Container c;
    JLabel lPID, lName, lMRP, lType, lCategory;
    JTextField tPID, tName, tMRP;
    JButton bAdd, bDelete, bNew, bUpdate, bExit;
    DefaultListModel<Object> mType;
    JList<Object> liType;
    DefaultComboBoxModel<Object> mCategory;
    JComboBox cbCategory;
    DefaultTableModel mProducts;
    JTable tProducts;

    Products() {

        c = getContentPane();
        setTitle("Products");
        setLayout(null);

        MyPic mp = new MyPic();
        mp.setBounds(1300, 10, 200, 300);
        c.add(mp);

        lPID = new JLabel("Product ID");
        lPID.setBounds(30, 20, 100, 30);
        c.add(lPID);

        tPID = new JTextField("");
        tPID.setBounds(140, 20, 100, 30);
        c.add(tPID);

        lName = new JLabel("Name");
        lName.setBounds(30, 70, 100, 30);
        c.add(lName);

        tName = new JTextField("");
        tName.setBounds(140, 70, 100, 30);
        c.add(tName);

        lMRP = new JLabel("MRP");
        lMRP.setBounds(30, 120, 100, 30);
        c.add(lMRP);

        tMRP = new JTextField("");
        tMRP.setBounds(140, 120, 100, 30);
        c.add(tMRP);

        lType = new JLabel("Type");
        lType.setBounds(30, 170, 100, 30);
        c.add(lType);

        mType = new DefaultListModel<Object>();
        liType = new JList<Object>(mType);
        JScrollPane jspType = new JScrollPane(liType);
        jspType.setBounds(140, 170, 100, 50);
        c.add(jspType);
        addType();

        lCategory = new JLabel("Category");
        lCategory.setBounds(30, 240, 100, 30);
        c.add(lCategory);

        mCategory = new DefaultComboBoxModel<Object>();
        cbCategory = new JComboBox<Object>(mCategory);
        cbCategory.setBounds(140, 240, 100, 30);
        c.add(cbCategory);
        addCategory();

        ImageIcon addImage = new ImageIcon("images/add.png");
        bAdd = new JButton("Add", addImage);
        bAdd.setBounds(30, 290, 100, 30);
        c.add(bAdd);
        bAdd.setBackground(Color.LIGHT_GRAY);

        ImageIcon deleteImage = new ImageIcon("images/delete.png");
        bDelete = new JButton("Delete", deleteImage);
        bDelete.setBounds(150, 290, 120, 30);
        c.add(bDelete);
        bDelete.setBackground(Color.LIGHT_GRAY);

        ImageIcon newImage = new ImageIcon("images/new.png");
        bNew = new JButton("New", newImage);
        bNew.setBounds(30, 340, 100, 30);
        c.add(bNew);
        bNew.setBackground(Color.LIGHT_GRAY);

        ImageIcon updateImage = new ImageIcon("images/update.png");
        bUpdate = new JButton("Update", updateImage);
        bUpdate.setBounds(150, 340, 120, 30);
        c.add(bUpdate);
        bUpdate.setBackground(Color.LIGHT_GRAY);

        ImageIcon exitImage = new ImageIcon("images/exit1.png");
        bExit = new JButton("Exit", exitImage);
        bExit.setBounds(80, 390, 100, 30);
        c.add(bExit);
        bExit.setBackground(Color.LIGHT_GRAY);
        String heads[] = {"PID", "Name", "MRP", "Type", "Category"};
        mProducts = new DefaultTableModel(heads, 0);
        tProducts = new JTable(mProducts);
        JScrollPane jspProducts = new JScrollPane(tProducts);
        jspProducts.setBounds(500, 30, 800, 300);
        c.add(jspProducts);
        fillProducts();

        bAdd.addActionListener(e -> add());
        bDelete.addActionListener(e -> delete());
        bNew.addActionListener(e -> New());
        bUpdate.addActionListener(e -> update());
        bExit.addActionListener(e -> System.exit(0));
        tProducts.addMouseListener(this);
        setVisible(true);
        setClosable(true);
        //setDefaultCloseOperation(3);
    }

    class MyPic extends JPanel implements Runnable {

        Image img = null;

        MyPic() {
            new Thread(this).start();
        }

        protected void paintComponent(Graphics g) {
            g.drawImage(img, 0, 0, this);
        }

        void setMyImage(String imageName) {
            img = new ImageIcon("images/products/"+imageName+".jpeg").getImage();
            repaint();
        }

        public void run() {
            try {
                int i = 1;
                while (true) {
                    if (i == 5) {
                        i = 1;
                    }
                    Thread.sleep(1000);
                    setMyImage(String.valueOf(i));
                    ++i;
                }
            } catch (Exception ex) {
            }
        }
    }

    void addType() {
        mType.addElement("None");
        mType.addElement("Veg");
        mType.addElement("Non-Vegetarian");
    }

    void addCategory() {
        mCategory.addElement("None");
        mCategory.addElement("Chinese");
        mCategory.addElement("South Indian");
        mCategory.addElement("Italian");

    }

    void fillProducts() {
        try {
            Connection con = Data.getConnection();
            PreparedStatement ps = con.prepareStatement("Select * from Products");
            ResultSet rs = ps.executeQuery();
            Vector<Object> v;
            while (rs.next()) {
                v = new Vector<Object>();
                v.add(rs.getInt(1));
                v.add(rs.getString(2));
                v.add(rs.getInt(3));
                v.add(rs.getString(4));
                v.add(rs.getString(5));
                mProducts.addRow(v);
            }
            con.close();
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(c, ex.toString());
        }
    }

    void add() {
        try {
            Connection con = Data.getConnection();
            PreparedStatement ps = con.prepareStatement("insert into Products values(?,?,?,?,?)");
            ps.setInt(1, Integer.parseInt(tPID.getText()));
            ps.setString(2, tName.getText());
            ps.setInt(3, Integer.parseInt(tMRP.getText()));
            ps.setString(4, liType.getSelectedValue().toString());
            ps.setString(5, cbCategory.getSelectedItem().toString());
            int count = ps.executeUpdate();
            if (count > 0) {
                JOptionPane.showMessageDialog(c, "Record Saved Successfully");
            }
            con.close();
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(c, ex.toString());
        }
        refreshMember();
        tName.setText("");
        tMRP.setText("");
        liType.clearSelection();
        tName.requestFocus();
        //cbCategory.setSelectedIndex(0);

    }

    void New() {
        try {

            Connection con = Data.getConnection();
            PreparedStatement ps = con.prepareStatement("Select Max(PID) from Products");
            ResultSet rs = ps.executeQuery();
            int nextId = 0;
            if (rs.next()) {
                nextId = rs.getInt(1);
            }
            ++nextId;

            tPID.setText(String.valueOf(nextId));
            con.close();
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(c, ex.toString());
        }
        tName.setText("");

        tName.requestFocus();
    }

    void update() {
        try {
            Connection con = Data.getConnection();
            PreparedStatement ps = con.prepareStatement("update Products set Name=?, MRP=?,Type=?,Category=? where id=?");

            ps.setString(1, tName.getText());
            ps.setInt(2, Integer.parseInt(tMRP.getText()));
            ps.setString(2, liType.getSelectedValue().toString());
            ps.setString(4, cbCategory.getSelectedItem().toString());
            ps.setInt(5, Integer.parseInt(tPID.getText()));
            int count = ps.executeUpdate();
            if (count > 0) {
                JOptionPane.showMessageDialog(c, "Updated Successfully!");
            }
            con.close();
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(c, ex.toString());
        }
        refreshMember();
    }

    void removeAllMember() {
        while (mProducts.getRowCount() > 0) {
            mProducts.removeRow(0);
        }

    }

    void refreshMember() {
        removeAllMember();
        fillProducts();
    }

    void delete() {
        try {
            Connection con = Data.getConnection();
            PreparedStatement ps = con.prepareStatement("delete from Products where PID=?");
            ps.setInt(1, Integer.parseInt(tPID.getText()));
            int count = ps.executeUpdate();
            if (count > 0) {
                JOptionPane.showMessageDialog(c, "Deleted");
            }
            con.close();
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(c, ex.toString());
        }

        refreshMember();

    }

    public void mousePressed(MouseEvent me) {

    }

    public void mouseReleased(MouseEvent me) {
        Object o = me.getSource();
        if (o.equals(tProducts)) {
            int row = tProducts.getSelectedRow();
            tPID.setText(String.valueOf(mProducts.getValueAt(row, 0)));
            tName.setText(String.valueOf(mProducts.getValueAt(row, 1)));
            tMRP.setText(String.valueOf(mProducts.getValueAt(row, 2)));
            liType.setSelectedValue(tProducts.getValueAt(row, 3), true);
            cbCategory.setSelectedItem(tProducts.getModel().getValueAt(row, 4));

        }
    }

    public void mouseClicked(MouseEvent me) {

    }

    public void mouseEntered(MouseEvent me) {

    }

    public void mouseExited(MouseEvent me) {

    }

}
