package fastfood;

import javax.swing.*;
import java.awt.*;
import java.sql.*;
import javax.swing.table.DefaultTableModel;

public class BillDetails extends JInternalFrame{

    Container c;

    BillDetails() {

        {
            setTitle(" Duplicate Bill Details");
            c = getContentPane();
            c.add(new MyPanel());

            setVisible(true);
            setClosable(true);

        }
    }

}
